<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2024-02-29 07:57:22 --- EMERGENCY: PDOException [ IM001 ]: SQLSTATE[IM001]: Driver does not support this function: driver does not support lastInsertId() ~ MODPATH\database\classes\Kohana\Database\PDO.php [ 198 ] in C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\PDO.php:198
2024-02-29 07:57:22 --- NOTICE: #0 C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\PDO.php(198): PDO->lastInsertId()
#1 C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_PDO->query(2, 'INSERT INTO bas...', false, Array)
#2 C:\xampp\htdocs\bas\application\classes\Model\bas.php(610): Kohana_Database_Query->execute(Object(Database_PDO))
#3 C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php(346): Model_Bas->updateData('10.200.25.2', 'admin', '171120444', '110')
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_update()
#5 [internal function]: Kohana_Controller->execute()
#6 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#7 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#10 {main} in C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\PDO.php:198
2024-02-29 08:00:52 --- EMERGENCY: PDOException [ IM001 ]: SQLSTATE[IM001]: Driver does not support this function: driver does not support lastInsertId() ~ MODPATH\database\classes\Kohana\Database\PDO.php [ 198 ] in C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\PDO.php:198
2024-02-29 08:00:52 --- NOTICE: #0 C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\PDO.php(198): PDO->lastInsertId()
#1 C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_PDO->query(2, 'INSERT INTO bas...', false, Array)
#2 C:\xampp\htdocs\bas\application\classes\Model\bas.php(620): Kohana_Database_Query->execute(Object(Database_PDO))
#3 C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php(346): Model_Bas->updateData('10.200.25.2', 'admin', '171120444', '110')
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_update()
#5 [internal function]: Kohana_Controller->execute()
#6 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#7 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#10 {main} in C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\PDO.php:198