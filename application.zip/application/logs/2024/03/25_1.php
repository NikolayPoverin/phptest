<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2024-03-25 16:50:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:04 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.20.2, id_dev= 101 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:04 --- NOTICE: rw=37 Панель 10.200.20.2 на связи 1, aa12fb, 1.9.0 20230928, 3.22.1, 2.10.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:04 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:04 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:04 --- NOTICE: 75 Ошибка валидации номера карты.<pre class="debug"><small>array</small><span>(1)</span> <span>(
    "ID_CARD" => <small>string</small><span>(37)</span> "Номер карты must be a digit"
)</span></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:04 --- NOTICE: 75-0 Ошибка валидации. key=" 10809903" Номер карты must be a digit in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:04 --- NOTICE: 75 Ошибка валидации номера карты.<pre class="debug"><small>array</small><span>(1)</span> <span>(
    "ID_CARD" => <small>string</small><span>(37)</span> "Номер карты must be a digit"
)</span></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:04 --- NOTICE: 75-0 Ошибка валидации. key=" 3147288" Номер карты must be a digit in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:04 --- NOTICE: 75 Ошибка валидации номера карты.<pre class="debug"><small>array</small><span>(1)</span> <span>(
    "ID_CARD" => <small>string</small><span>(37)</span> "Номер карты must be a digit"
)</span></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:04 --- NOTICE: 75-0 Ошибка валидации. key=" 3147288" Номер карты must be a digit in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:04 --- NOTICE: 16:50:04 rw- 137 работа с контроллером 10.200.20.2 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:04 --- NOTICE: 253 Проблема с авторизациейError fetching remote http:///api/v1/login [ status 0 ] Could not resolve host: http:; Host not found in C:\xampp\htdocs\bas\application\classes\Model\basoop.php:93
2024-03-25 16:50:04 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью , id_dev= 110 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:04 --- NOTICE: event-151 с контроллером  связи нет in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:05 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.12.4, id_dev= 182 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:05 --- NOTICE: rw=37 Панель 10.200.12.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:05 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:05 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:05 --- NOTICE: 75 Ошибка валидации номера карты.<pre class="debug"><small>array</small><span>(1)</span> <span>(
    "ID_CARD" => <small>string</small><span>(37)</span> "Номер карты must be a digit"
)</span></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:05 --- NOTICE: 75-0 Ошибка валидации. key=" 3147288" Номер карты must be a digit in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:05 --- NOTICE: 75 Ошибка валидации номера карты.<pre class="debug"><small>array</small><span>(1)</span> <span>(
    "ID_CARD" => <small>string</small><span>(37)</span> "Номер карты must be a digit"
)</span></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:05 --- NOTICE: 75-0 Ошибка валидации. key=" 3147288" Номер карты must be a digit in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:05 --- NOTICE: 75 Ошибка валидации номера карты.<pre class="debug"><small>array</small><span>(1)</span> <span>(
    "ID_CARD" => <small>string</small><span>(37)</span> "Номер карты must be a digit"
)</span></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:05 --- NOTICE: 75-0 Ошибка валидации. key=" 3147288" Номер карты must be a digit in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:05 --- NOTICE: 16:50:05 rw- 137 работа с контроллером 10.200.12.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:05 --- NOTICE: 142 stop minion basrwrfid.php. timeExecute=1.6593959331512 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:06 --- NOTICE: event-14 start basgetevent.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:07 --- NOTICE: ev=34 Начало работы с панелью 10.200.20.2, id_dev= 101, device="2.1 Вест". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:07 --- NOTICE: #43 Панель 10.200.20.2 на связи 1, aa12fb, 1.9.0 20230928, 3.22.1, 2.10.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:07 --- NOTICE: event-43 провожу авторизацию панели id_dev=101, id_ctrl=25,  baseurl=10.200.20.2,  name='2.1 Вест' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:07 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:07 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 16:50:07 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 16:15:10 (1711376110153) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 16:50:12 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:12 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:12 --- NOTICE: 16:50:12 ev- 137 работа с контроллером 10.200.20.2 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:12 --- NOTICE: ev=34 Начало работы с панелью 10.200.15.4, id_dev= 149, device="1.5 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:12 --- NOTICE: #43 Панель 10.200.15.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:12 --- NOTICE: event-43 провожу авторизацию панели id_dev=149, id_ctrl=39,  baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:12 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 16:50:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 16:50:13 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:13 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:13 --- NOTICE: 16:50:13 ev- 137 работа с контроллером 10.200.15.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:13 --- NOTICE: ev=34 Начало работы с панелью 10.200.12.4, id_dev= 182, device="1.2 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:13 --- NOTICE: #43 Панель 10.200.12.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:13 --- NOTICE: event-43 провожу авторизацию панели id_dev=182, id_ctrl=50,  baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:13 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 16:50:13 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 16:50:13 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:13 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:13 --- NOTICE: 16:50:13 ev- 137 работа с контроллером 10.200.12.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:50:13 --- NOTICE: event-142 stop minion basgetevent.php. Выборка событий завершена. Время выполнения timeExecute=7.0445110797882 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:03 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.20.2, id_dev= 101 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:03 --- NOTICE: rw=37 Панель 10.200.20.2 на связи 1, aa12fb, 1.9.0 20230928, 3.22.1, 2.10.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:03 --- NOTICE: 75 Ошибка валидации. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:03 --- NOTICE: 75 Ошибка валидации. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:03 --- NOTICE: 75 Ошибка валидации. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:03 --- NOTICE: 16:55:03 rw- 137 работа с контроллером 10.200.20.2 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:03 --- NOTICE: 253 Проблема с авторизациейError fetching remote http:///api/v1/login [ status 0 ] Could not resolve host: http:; Host not found in C:\xampp\htdocs\bas\application\classes\Model\basoop.php:93
2024-03-25 16:55:03 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью , id_dev= 110 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:03 --- NOTICE: event-151 с контроллером  связи нет in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:04 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.12.4, id_dev= 182 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:04 --- NOTICE: rw=37 Панель 10.200.12.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:04 --- NOTICE: 75 Ошибка валидации. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:04 --- NOTICE: 75 Ошибка валидации. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:04 --- NOTICE: 75 Ошибка валидации. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:04 --- NOTICE: 16:55:04 rw- 137 работа с контроллером 10.200.12.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:04 --- NOTICE: 142 stop minion basrwrfid.php. timeExecute=1.569216966629 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:06 --- NOTICE: event-14 start basgetevent.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:07 --- NOTICE: ev=34 Начало работы с панелью 10.200.20.2, id_dev= 101, device="2.1 Вест". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:07 --- NOTICE: #43 Панель 10.200.20.2 на связи 1, aa12fb, 1.9.0 20230928, 3.22.1, 2.10.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:07 --- NOTICE: event-43 провожу авторизацию панели id_dev=101, id_ctrl=25,  baseurl=10.200.20.2,  name='2.1 Вест' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:07 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:07 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 16:55:07 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 16:15:10 (1711376110153) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 16:55:12 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:12 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:12 --- NOTICE: 16:55:12 ev- 137 работа с контроллером 10.200.20.2 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:12 --- NOTICE: ev=34 Начало работы с панелью 10.200.15.4, id_dev= 149, device="1.5 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:12 --- NOTICE: #43 Панель 10.200.15.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:12 --- NOTICE: event-43 провожу авторизацию панели id_dev=149, id_ctrl=39,  baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:12 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 16:55:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 16:55:13 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:13 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:13 --- NOTICE: 16:55:13 ev- 137 работа с контроллером 10.200.15.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:13 --- NOTICE: ev=34 Начало работы с панелью 10.200.12.4, id_dev= 182, device="1.2 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:13 --- NOTICE: #43 Панель 10.200.12.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:13 --- NOTICE: event-43 провожу авторизацию панели id_dev=182, id_ctrl=50,  baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:13 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 16:55:13 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 16:55:13 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:13 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:13 --- NOTICE: 16:55:13 ev- 137 работа с контроллером 10.200.12.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 16:55:13 --- NOTICE: event-142 stop minion basgetevent.php. Выборка событий завершена. Время выполнения timeExecute=7.2291419506073 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:04 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.20.2, id_dev= 101 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:04 --- NOTICE: rw=37 Панель 10.200.20.2 на связи 1, aa12fb, 1.9.0 20230928, 3.22.1, 2.10.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:04 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:04 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:04 --- NOTICE: 17:00:04 rw- 137 работа с контроллером 10.200.20.2 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:04 --- NOTICE: 253 Проблема с авторизацией для  Error fetching remote http:///api/v1/login [ status 0 ] Could not resolve host: http:; Host not found in C:\xampp\htdocs\bas\application\classes\Model\basoop.php:93
2024-03-25 17:00:04 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью , id_dev= 110 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:04 --- NOTICE: event-151 с контроллером  связи нет in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:04 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.12.4, id_dev= 182 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:04 --- NOTICE: rw=37 Панель 10.200.12.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:04 --- NOTICE: 17:00:04 rw- 137 работа с контроллером 10.200.12.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:04 --- NOTICE: 142 stop minion basrwrfid.php. timeExecute=1.6206669807434 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:06 --- NOTICE: event-14 start basgetevent.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:06 --- NOTICE: ev=34 Начало работы с панелью 10.200.20.2, id_dev= 101, device="2.1 Вест". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:06 --- NOTICE: #43 Панель 10.200.20.2 на связи 1, aa12fb, 1.9.0 20230928, 3.22.1, 2.10.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:06 --- NOTICE: event-43 провожу авторизацию панели id_dev=101, id_ctrl=25,  baseurl=10.200.20.2,  name='2.1 Вест' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:06 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:00:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 16:15:10 (1711376110153) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:00:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:11 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:11 --- NOTICE: 17:00:11 ev- 137 работа с контроллером 10.200.20.2 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:12 --- NOTICE: ev=34 Начало работы с панелью 10.200.15.4, id_dev= 149, device="1.5 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:12 --- NOTICE: #43 Панель 10.200.15.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:12 --- NOTICE: event-43 провожу авторизацию панели id_dev=149, id_ctrl=39,  baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:12 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:00:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:00:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:12 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:12 --- NOTICE: 17:00:12 ev- 137 работа с контроллером 10.200.15.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:12 --- NOTICE: ev=34 Начало работы с панелью 10.200.12.4, id_dev= 182, device="1.2 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:12 --- NOTICE: #43 Панель 10.200.12.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:12 --- NOTICE: event-43 провожу авторизацию панели id_dev=182, id_ctrl=50,  baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:12 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:00:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:00:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:12 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:12 --- NOTICE: 17:00:12 ev- 137 работа с контроллером 10.200.12.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:00:12 --- NOTICE: event-142 stop minion basgetevent.php. Выборка событий завершена. Время выполнения timeExecute=6.5842089653015 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:03 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.20.2, id_dev= 101 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:03 --- NOTICE: rw=37 Панель 10.200.20.2 на связи 1, aa12fb, 1.9.0 20230928, 3.22.1, 2.10.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:03 --- NOTICE: 17:05:03 rw- 137 работа с контроллером 10.200.20.2 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:03 --- NOTICE: 253 Проблема с авторизацией для  Error fetching remote http:///api/v1/login [ status 0 ] Could not resolve host: http:; Host not found in C:\xampp\htdocs\bas\application\classes\Model\basoop.php:93
2024-03-25 17:05:03 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью , id_dev= 110 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:03 --- NOTICE: event-151 с контроллером  связи нет in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:04 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.12.4, id_dev= 182 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:04 --- NOTICE: rw=37 Панель 10.200.12.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:04 --- NOTICE: 17:05:04 rw- 137 работа с контроллером 10.200.12.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:04 --- NOTICE: 142 stop minion basrwrfid.php. timeExecute=1.5504441261292 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:06 --- NOTICE: event-14 start basgetevent.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:06 --- NOTICE: ev=34 Начало работы с панелью 10.200.20.2, id_dev= 101, device="2.1 Вест". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:06 --- NOTICE: #43 Панель 10.200.20.2 на связи 1, aa12fb, 1.9.0 20230928, 3.22.1, 2.10.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:06 --- NOTICE: event-43 провожу авторизацию панели id_dev=101, id_ctrl=25,  baseurl=10.200.20.2,  name='2.1 Вест' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:06 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:05:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 16:15:10 (1711376110153) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:05:12 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:12 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:12 --- NOTICE: 17:05:12 ev- 137 работа с контроллером 10.200.20.2 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:13 --- NOTICE: ev=34 Начало работы с панелью 10.200.15.4, id_dev= 149, device="1.5 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:13 --- NOTICE: #43 Панель 10.200.15.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:13 --- NOTICE: event-43 провожу авторизацию панели id_dev=149, id_ctrl=39,  baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:13 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:05:13 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:05:13 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:13 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:13 --- NOTICE: 17:05:13 ev- 137 работа с контроллером 10.200.15.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:13 --- NOTICE: ev=34 Начало работы с панелью 10.200.12.4, id_dev= 182, device="1.2 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:13 --- NOTICE: #43 Панель 10.200.12.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:13 --- NOTICE: event-43 провожу авторизацию панели id_dev=182, id_ctrl=50,  baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:13 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:05:13 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:05:13 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:13 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:13 --- NOTICE: 17:05:13 ev- 137 работа с контроллером 10.200.12.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:05:13 --- NOTICE: event-142 stop minion basgetevent.php. Выборка событий завершена. Время выполнения timeExecute=7.553817987442 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:07 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.20.2, id_dev= 101 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:07 --- NOTICE: rw=37 Панель 10.200.20.2 на связи 1, aa12fb, 1.9.0 20230928, 3.22.1, 2.10.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:07 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:07 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:07 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:07 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:07 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:07 --- NOTICE: 17:10:07 rw- 137 работа с контроллером 10.200.20.2 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:07 --- NOTICE: 253 Проблема с авторизацией для  Error fetching remote http:///api/v1/login [ status 0 ] Could not resolve host: http:; Host not found in C:\xampp\htdocs\bas\application\classes\Model\basoop.php:102
2024-03-25 17:10:07 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью , id_dev= 110 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:07 --- NOTICE: event-151 с контроллером  связи нет in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:09 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.12.4, id_dev= 182 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:09 --- NOTICE: rw=37 Панель 10.200.12.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:09 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:09 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:09 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:09 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:09 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:09 --- NOTICE: 17:10:09 rw- 137 работа с контроллером 10.200.12.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:09 --- NOTICE: 142 stop minion basrwrfid.php. timeExecute=5.8198249340057 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:10 --- NOTICE: event-14 start basgetevent.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:11 --- NOTICE: ev=34 Начало работы с панелью 10.200.20.2, id_dev= 101, device="2.1 Вест". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:11 --- NOTICE: #43 Панель 10.200.20.2 на связи 1, aa12fb, 1.9.0 20230928, 3.22.1, 2.10.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:11 --- NOTICE: event-43 провожу авторизацию панели id_dev=101, id_ctrl=25,  baseurl=10.200.20.2,  name='2.1 Вест' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:11 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:10:11 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 16:15:10 (1711376110153) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:10:16 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:16 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:16 --- NOTICE: 17:10:16 ev- 137 работа с контроллером 10.200.20.2 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:16 --- NOTICE: ev=34 Начало работы с панелью 10.200.15.4, id_dev= 149, device="1.5 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:16 --- NOTICE: #43 Панель 10.200.15.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:16 --- NOTICE: event-43 провожу авторизацию панели id_dev=149, id_ctrl=39,  baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:16 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:16 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:10:16 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:10:16 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:16 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:16 --- NOTICE: 17:10:16 ev- 137 работа с контроллером 10.200.15.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:16 --- NOTICE: ev=34 Начало работы с панелью 10.200.12.4, id_dev= 182, device="1.2 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:16 --- NOTICE: #43 Панель 10.200.12.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:16 --- NOTICE: event-43 провожу авторизацию панели id_dev=182, id_ctrl=50,  baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:16 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:16 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:10:16 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:10:16 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:16 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:16 --- NOTICE: 17:10:16 ev- 137 работа с контроллером 10.200.12.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:10:16 --- NOTICE: event-142 stop minion basgetevent.php. Выборка событий завершена. Время выполнения timeExecute=6.3530180454254 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:03 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.20.2, id_dev= 101 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:03 --- NOTICE: rw=37 Панель 10.200.20.2 на связи 1, aa12fb, 1.9.0 20230928, 3.22.1, 2.10.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:03 --- NOTICE: 17:15:03 rw- 137 работа с контроллером 10.200.20.2 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:03 --- NOTICE: 253 Проблема с авторизацией для  Error fetching remote http:///api/v1/login [ status 0 ] Could not resolve host: http:; Host not found in C:\xampp\htdocs\bas\application\classes\Model\basoop.php:104
2024-03-25 17:15:03 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью , id_dev= 110 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:03 --- NOTICE: event-151 с контроллером  связи нет in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:04 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.12.4, id_dev= 182 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:04 --- NOTICE: rw=37 Панель 10.200.12.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:04 --- NOTICE: 17:15:04 rw- 137 работа с контроллером 10.200.12.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:04 --- NOTICE: 142 stop minion basrwrfid.php. timeExecute=1.5303549766541 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:06 --- NOTICE: event-14 start basgetevent.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:06 --- NOTICE: ev=34 Начало работы с панелью 10.200.20.2, id_dev= 101, device="2.1 Вест". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:06 --- NOTICE: #43 Панель 10.200.20.2 на связи 1, aa12fb, 1.9.0 20230928, 3.22.1, 2.10.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:06 --- NOTICE: event-43 провожу авторизацию панели id_dev=101, id_ctrl=25,  baseurl=10.200.20.2,  name='2.1 Вест' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:06 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:15:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 16:15:10 (1711376110153) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:15:12 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:12 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:12 --- NOTICE: 17:15:12 ev- 137 работа с контроллером 10.200.20.2 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:12 --- NOTICE: ev=34 Начало работы с панелью 10.200.15.4, id_dev= 149, device="1.5 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:12 --- NOTICE: #43 Панель 10.200.15.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:12 --- NOTICE: event-43 провожу авторизацию панели id_dev=149, id_ctrl=39,  baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:12 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:15:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:15:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:12 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:12 --- NOTICE: 17:15:12 ev- 137 работа с контроллером 10.200.15.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:12 --- NOTICE: ev=34 Начало работы с панелью 10.200.12.4, id_dev= 182, device="1.2 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:12 --- NOTICE: #43 Панель 10.200.12.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:12 --- NOTICE: event-43 провожу авторизацию панели id_dev=182, id_ctrl=50,  baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:12 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:15:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:15:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:12 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:12 --- NOTICE: 17:15:12 ev- 137 работа с контроллером 10.200.12.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:15:12 --- NOTICE: event-142 stop minion basgetevent.php. Выборка событий завершена. Время выполнения timeExecute=6.6719920635223 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:03 --- NOTICE: 415 test IP= 10.200.20.2 in C:\xampp\htdocs\bas\application\classes\Model\basoop.php:104
2024-03-25 17:20:03 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.20.2, id_dev= 101 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:03 --- NOTICE: rw=37 Панель 10.200.20.2 на связи 1, aa12fb, 1.9.0 20230928, 3.22.1, 2.10.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:03 --- NOTICE: 17:20:03 rw- 137 работа с контроллером 10.200.20.2 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:03 --- NOTICE: 415 test IP=  in C:\xampp\htdocs\bas\application\classes\Model\basoop.php:104
2024-03-25 17:20:03 --- NOTICE: 253 Проблема с авторизацией для  Error fetching remote http:///api/v1/login [ status 0 ] Could not resolve host: http:; Host not found in C:\xampp\htdocs\bas\application\classes\Model\basoop.php:104
2024-03-25 17:20:03 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью , id_dev= 110 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:03 --- NOTICE: event-151 с контроллером  связи нет in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:04 --- NOTICE: 415 test IP= 10.200.12.4 in C:\xampp\htdocs\bas\application\classes\Model\basoop.php:104
2024-03-25 17:20:04 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.12.4, id_dev= 182 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:04 --- NOTICE: rw=37 Панель 10.200.12.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:04 --- NOTICE: 17:20:04 rw- 137 работа с контроллером 10.200.12.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:04 --- NOTICE: 142 stop minion basrwrfid.php. timeExecute=1.5475218296051 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:06 --- NOTICE: event-14 start basgetevent.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:06 --- NOTICE: 415 test IP= 10.200.20.2 in C:\xampp\htdocs\bas\application\classes\Model\basoop.php:104
2024-03-25 17:20:06 --- NOTICE: ev=34 Начало работы с панелью 10.200.20.2, id_dev= 101, device="2.1 Вест". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:06 --- NOTICE: #43 Панель 10.200.20.2 на связи 1, aa12fb, 1.9.0 20230928, 3.22.1, 2.10.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:06 --- NOTICE: event-43 провожу авторизацию панели id_dev=101, id_ctrl=25,  baseurl=10.200.20.2,  name='2.1 Вест' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:06 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:20:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 16:15:10 (1711376110153) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:20:12 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:12 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:12 --- NOTICE: 17:20:12 ev- 137 работа с контроллером 10.200.20.2 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:12 --- NOTICE: 415 test IP= 10.200.15.4 in C:\xampp\htdocs\bas\application\classes\Model\basoop.php:104
2024-03-25 17:20:12 --- NOTICE: ev=34 Начало работы с панелью 10.200.15.4, id_dev= 149, device="1.5 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:12 --- NOTICE: #43 Панель 10.200.15.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:12 --- NOTICE: event-43 провожу авторизацию панели id_dev=149, id_ctrl=39,  baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:12 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:20:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:20:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:12 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:12 --- NOTICE: 17:20:12 ev- 137 работа с контроллером 10.200.15.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:12 --- NOTICE: 415 test IP= 10.200.12.4 in C:\xampp\htdocs\bas\application\classes\Model\basoop.php:104
2024-03-25 17:20:12 --- NOTICE: ev=34 Начало работы с панелью 10.200.12.4, id_dev= 182, device="1.2 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:12 --- NOTICE: #43 Панель 10.200.12.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:12 --- NOTICE: event-43 провожу авторизацию панели id_dev=182, id_ctrl=50,  baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:12 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:20:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:20:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:12 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:12 --- NOTICE: 17:20:12 ev- 137 работа с контроллером 10.200.12.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:20:12 --- NOTICE: event-142 stop minion basgetevent.php. Выборка событий завершена. Время выполнения timeExecute=6.6163048744202 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:03 --- NOTICE: 415 test IP= 10.200.20.2 in C:\xampp\htdocs\bas\application\classes\Task\basrwrfid.php:46
2024-03-25 17:25:03 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.20.2, id_dev= 101 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:03 --- NOTICE: rw=37 Панель 10.200.20.2 на связи 1, aa12fb, 1.9.0 20230928, 3.22.1, 2.10.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:03 --- NOTICE: 17:25:03 rw- 137 работа с контроллером 10.200.20.2 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:03 --- NOTICE: 415 test IP=  in C:\xampp\htdocs\bas\application\classes\Task\basrwrfid.php:46
2024-03-25 17:25:03 --- NOTICE: 253 Проблема с авторизацией для  Error fetching remote http:///api/v1/login [ status 0 ] Could not resolve host: http:; Host not found in C:\xampp\htdocs\bas\application\classes\Model\basoop.php:105
2024-03-25 17:25:03 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью , id_dev= 110 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:03 --- NOTICE: event-151 с контроллером  связи нет in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:04 --- NOTICE: 415 test IP= 10.200.12.4 in C:\xampp\htdocs\bas\application\classes\Task\basrwrfid.php:46
2024-03-25 17:25:04 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.12.4, id_dev= 182 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:04 --- NOTICE: rw=37 Панель 10.200.12.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:04 --- NOTICE: 17:25:04 rw- 137 работа с контроллером 10.200.12.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:04 --- NOTICE: 142 stop minion basrwrfid.php. timeExecute=1.6413700580597 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:06 --- NOTICE: event-14 start basgetevent.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:06 --- NOTICE: 415 test IP= 10.200.20.2 in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:45
2024-03-25 17:25:06 --- NOTICE: ev=34 Начало работы с панелью 10.200.20.2, id_dev= 101, device="2.1 Вест". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:06 --- NOTICE: #43 Панель 10.200.20.2 на связи 1, aa12fb, 1.9.0 20230928, 3.22.1, 2.10.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:06 --- NOTICE: event-43 провожу авторизацию панели id_dev=101, id_ctrl=25,  baseurl=10.200.20.2,  name='2.1 Вест' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:07 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:25:07 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 16:15:10 (1711376110153) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:25:12 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 2 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:12 --- NOTICE: event-87 Дверь открыта картой 9793878 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:12 --- NOTICE: +Device="2.1 Вест, Readdate =#25.03.2024 17:25:12#, DeviceDate=#25.03.2024 17:24:57#, EventCode=50, Door=0, EventIndex=1711380297096, Card="9793878" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:12 --- NOTICE: event-87 Дверь открыта картой 9793664 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:12 --- NOTICE: +Device="2.1 Вест, Readdate =#25.03.2024 17:25:12#, DeviceDate=#25.03.2024 17:25:16#, EventCode=50, Door=0, EventIndex=1711380316697, Card="9793664" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:12 --- NOTICE: 17:25:12 ev- 137 работа с контроллером 10.200.20.2 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:12 --- NOTICE: 415 test IP= 10.200.15.4 in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:45
2024-03-25 17:25:12 --- NOTICE: ev=34 Начало работы с панелью 10.200.15.4, id_dev= 149, device="1.5 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:12 --- NOTICE: #43 Панель 10.200.15.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:12 --- NOTICE: event-43 провожу авторизацию панели id_dev=149, id_ctrl=39,  baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:12 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:25:13 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:25:13 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:13 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:13 --- NOTICE: 17:25:13 ev- 137 работа с контроллером 10.200.15.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:13 --- NOTICE: 415 test IP= 10.200.12.4 in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:45
2024-03-25 17:25:13 --- NOTICE: ev=34 Начало работы с панелью 10.200.12.4, id_dev= 182, device="1.2 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:13 --- NOTICE: #43 Панель 10.200.12.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:13 --- NOTICE: event-43 провожу авторизацию панели id_dev=182, id_ctrl=50,  baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:13 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:25:13 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:25:13 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:13 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:13 --- NOTICE: 17:25:13 ev- 137 работа с контроллером 10.200.12.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:25:13 --- NOTICE: event-142 stop minion basgetevent.php. Выборка событий завершена. Время выполнения timeExecute=7.1484360694885 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:04 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.20.2, id_dev= 101 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:04 --- NOTICE: rw=37 Панель 10.200.20.2 на связи 1, aa12fb, 1.9.0 20230928, 3.22.1, 2.10.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:04 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:04 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:04 --- NOTICE: 17:30:04 rw- 137 работа с контроллером 10.200.20.2 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:04 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.32.3, id_dev= 110 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:04 --- NOTICE: rw=37 Панель 10.200.32.3 на связи 1, aa12b, 1.8.0 20210129, 3.10.0, 2.0.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 13 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key="15408069" Номер карты must be at least 10 characters long Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:04 --- NOTICE: 304 Удаление карт для 10.200.32.3. Результат поиска UID в панели <pre class="debug"><small>array</small><span>(2)</span> <span>(
    "status" => <small>integer</small> 200
    "res" => <small>integer</small> 3628
)</span></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:04 --- NOTICE: 286 Удаление карты для IP 10.200.32.3, которая найдена в контроллере <pre class="debug"><small>array</small><span>(2)</span> <span>(
    "status" => <small>integer</small> 200
    "res" => <small>integer</small> 3628
)</span>
<small>array</small><span>(4)</span> <span>(
    "ID_CARDINDEV" => <small>string</small><span>(6)</span> "955752"
    "ID_CARD" => <small>string</small><span>(7)</span> "4118055"
    "ID_DEV" => <small>string</small><span>(3)</span> "111"
    "OPERATION" => <small>string</small><span>(1)</span> "2"
)</span></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:04 --- NOTICE: 304 Удаление карт для 10.200.32.3. Результат поиска UID в панели <pre class="debug"><small>array</small><span>(2)</span> <span>(
    "status" => <small>integer</small> 200
    "res" => <small>NULL</small>
)</span></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:04 --- NOTICE: 286 Удаление карты для 10.200.32.3. Карты в контроллере нет, удаляю только строку из таблицы cardindev.<pre class="debug"><small>array</small><span>(4)</span> <span>(
    "ID_CARDINDEV" => <small>string</small><span>(6)</span> "956591"
    "ID_CARD" => <small>string</small><span>(8)</span> "16096976"
    "ID_DEV" => <small>string</small><span>(3)</span> "111"
    "OPERATION" => <small>string</small><span>(1)</span> "2"
)</span></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key="14196596" Номер карты must be at least 10 characters long Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key="4118055" Номер карты must be at least 10 characters long Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:04 --- NOTICE: 304 Удаление карт для 10.200.32.3. Результат поиска UID в панели <pre class="debug"><small>array</small><span>(2)</span> <span>(
    "status" => <small>integer</small> 200
    "res" => <small>NULL</small>
)</span></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:04 --- NOTICE: 286 Удаление карты для 10.200.32.3. Карты в контроллере нет, удаляю только строку из таблицы cardindev.<pre class="debug"><small>array</small><span>(4)</span> <span>(
    "ID_CARDINDEV" => <small>string</small><span>(6)</span> "956549"
    "ID_CARD" => <small>string</small><span>(8)</span> "16069468"
    "ID_DEV" => <small>string</small><span>(3)</span> "111"
    "OPERATION" => <small>string</small><span>(1)</span> "2"
)</span></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key="16093866" Номер карты must be at least 10 characters long Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key="16081484" Номер карты must be at least 10 characters long Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:05 --- NOTICE: 304 Удаление карт для 10.200.32.3. Результат поиска UID в панели <pre class="debug"><small>array</small><span>(2)</span> <span>(
    "status" => <small>integer</small> 200
    "res" => <small>NULL</small>
)</span></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:05 --- NOTICE: 286 Удаление карты для 10.200.32.3. Карты в контроллере нет, удаляю только строку из таблицы cardindev.<pre class="debug"><small>array</small><span>(4)</span> <span>(
    "ID_CARDINDEV" => <small>string</small><span>(6)</span> "956658"
    "ID_CARD" => <small>string</small><span>(7)</span> "8776448"
    "ID_DEV" => <small>string</small><span>(3)</span> "111"
    "OPERATION" => <small>string</small><span>(1)</span> "2"
)</span></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:05 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key="16079749" Номер карты must be at least 10 characters long Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:05 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:05 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key="16104318" Номер карты must be at least 10 characters long Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:05 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:05 --- NOTICE: 17:30:05 rw- 137 работа с контроллером 10.200.32.3 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:05 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.12.4, id_dev= 182 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:05 --- NOTICE: rw=37 Панель 10.200.12.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:05 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:05 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:05 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:05 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:05 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:05 --- NOTICE: 17:30:05 rw- 137 работа с контроллером 10.200.12.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:05 --- NOTICE: 142 stop minion basrwrfid.php. timeExecute=1.8451330661774 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:07 --- NOTICE: event-14 start basgetevent.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:07 --- NOTICE: ev=34 Начало работы с панелью 10.200.20.2, id_dev= 101, device="2.1 Вест". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:07 --- NOTICE: #43 Панель 10.200.20.2 на связи 1, aa12fb, 1.9.0 20230928, 3.22.1, 2.10.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:07 --- NOTICE: event-43 провожу авторизацию панели id_dev=101, id_ctrl=25,  baseurl=10.200.20.2,  name='2.1 Вест' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:07 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:07 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:30:07 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 17:25:16 (1711380316697) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:30:13 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:13 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:13 --- NOTICE: 17:30:13 ev- 137 работа с контроллером 10.200.20.2 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:13 --- NOTICE: ev=34 Начало работы с панелью 10.200.32.3, id_dev= 110, device="2.4 Вест". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:13 --- NOTICE: #43 Панель 10.200.32.3 на связи 1, aa12b, 1.8.0 20210129, 3.10.0, 2.0.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:13 --- NOTICE: event-43 провожу авторизацию панели id_dev=110, id_ctrl=28,  baseurl=10.200.32.3,  name='2.4 Вест' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:13 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:30:13 --- NOTICE: #545 Получение событий начиная с метки 27.02.2024 08:01:19 (1709013679099) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:30:13 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 50 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:13 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710861502667
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:13 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710861502922
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:13, DeviceDate=#19.03.2024 17:19:22, EventCode=49, Door=0, EventIndex=1710861562458 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:13 --- NOTICE: event-87 Дверь открыта картой 8105360 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:13#, DeviceDate=#19.03.2024 17:25:53#, EventCode=50, Door=0, EventIndex=1710861953334, Card="8105360" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:13, DeviceDate=#19.03.2024 17:26:07, EventCode=90, Door=0, EventIndex=1710861967208 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:13 --- NOTICE: event-87 Дверь открыта картой 8105336 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:13#, DeviceDate=#19.03.2024 17:26:37#, EventCode=50, Door=0, EventIndex=1710861997850, Card="8105336" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:13 --- NOTICE: event-87 Дверь открыта картой 5253488 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:13#, DeviceDate=#19.03.2024 17:29:40#, EventCode=50, Door=0, EventIndex=1710862180941, Card="5253488" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:13, DeviceDate=#19.03.2024 17:31:46, EventCode=49, Door=0, EventIndex=1710862306592 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:13 --- NOTICE: event-87 Дверь открыта картой 8105344 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:13#, DeviceDate=#19.03.2024 17:34:17#, EventCode=50, Door=0, EventIndex=1710862457017, Card="8105344" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:13 --- NOTICE: event-87 Дверь открыта картой 1376468 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:13#, DeviceDate=#19.03.2024 17:35:26#, EventCode=50, Door=0, EventIndex=1710862526271, Card="1376468" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:13 --- NOTICE: event-87 Дверь открыта картой 8105318 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:14#, DeviceDate=#19.03.2024 17:36:29#, EventCode=50, Door=0, EventIndex=1710862589244, Card="8105318" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:14, DeviceDate=#19.03.2024 17:36:52, EventCode=49, Door=0, EventIndex=1710862612564 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:14, DeviceDate=#19.03.2024 17:47:21, EventCode=49, Door=0, EventIndex=1710863241498 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:14, DeviceDate=#19.03.2024 17:50:18, EventCode=49, Door=0, EventIndex=1710863418240 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: event-87 Дверь открыта картой 8105344 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:14#, DeviceDate=#19.03.2024 17:50:58#, EventCode=50, Door=0, EventIndex=1710863458160, Card="8105344" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:14, DeviceDate=#19.03.2024 17:56:14, EventCode=49, Door=0, EventIndex=1710863774456 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: event-87 Дверь открыта картой 9793711 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:14#, DeviceDate=#19.03.2024 17:58:23#, EventCode=50, Door=0, EventIndex=1710863903704, Card="9793711" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710863939788
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710863940057
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710863940168
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710863940631
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:14, DeviceDate=#19.03.2024 18:00:49, EventCode=49, Door=0, EventIndex=1710864049596 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:14, DeviceDate=#19.03.2024 18:01:57, EventCode=49, Door=0, EventIndex=1710864117758 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:14, DeviceDate=#19.03.2024 18:02:28, EventCode=49, Door=0, EventIndex=1710864148721 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:14, DeviceDate=#19.03.2024 18:06:55, EventCode=49, Door=0, EventIndex=1710864415510 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:14, DeviceDate=#19.03.2024 18:09:26, EventCode=49, Door=0, EventIndex=1710864566427 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:14, DeviceDate=#19.03.2024 18:13:10, EventCode=90, Door=0, EventIndex=1710864790012 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:14, DeviceDate=#19.03.2024 18:15:59, EventCode=49, Door=0, EventIndex=1710864959580 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:14, DeviceDate=#19.03.2024 18:17:08, EventCode=49, Door=0, EventIndex=1710865028232 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:14, DeviceDate=#19.03.2024 18:17:32, EventCode=90, Door=0, EventIndex=1710865052477 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:14, DeviceDate=#19.03.2024 18:25:12, EventCode=49, Door=0, EventIndex=1710865512110 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: event-87 Дверь открыта картой 3530279 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:14#, DeviceDate=#19.03.2024 18:34:45#, EventCode=50, Door=0, EventIndex=1710866085366, Card="3530279" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:14, DeviceDate=#19.03.2024 18:35:22, EventCode=49, Door=0, EventIndex=1710866122006 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:14, DeviceDate=#19.03.2024 18:35:59, EventCode=49, Door=0, EventIndex=1710866159268 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:14, DeviceDate=#19.03.2024 18:36:16, EventCode=49, Door=0, EventIndex=1710866176148 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710866312981
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710866313303
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710866362776
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(29)</span> "access_denied_by_unknown_card"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710866372860
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:14 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710866373115
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:15 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710866488150
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:15 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710866488422
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:15 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:15, DeviceDate=#19.03.2024 18:41:57, EventCode=49, Door=0, EventIndex=1710866517245 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:15 --- NOTICE: event-87 Дверь открыта картой 8105288 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:15 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:15#, DeviceDate=#19.03.2024 18:42:16#, EventCode=50, Door=0, EventIndex=1710866536799, Card="8105288" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:15 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:15, DeviceDate=#19.03.2024 18:43:29, EventCode=49, Door=0, EventIndex=1710866609513 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:15 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:15, DeviceDate=#19.03.2024 18:43:43, EventCode=49, Door=0, EventIndex=1710866623249 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:15 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:15, DeviceDate=#19.03.2024 18:45:17, EventCode=49, Door=0, EventIndex=1710866717802 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:15 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:30:15, DeviceDate=#19.03.2024 18:46:34, EventCode=49, Door=0, EventIndex=1710866794456 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:15 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710866951366
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:15 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710866951503
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:15 --- NOTICE: 17:30:15 ev- 137 работа с контроллером 10.200.32.3 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:15 --- NOTICE: ev=34 Начало работы с панелью 10.200.15.4, id_dev= 149, device="1.5 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:15 --- NOTICE: #43 Панель 10.200.15.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:15 --- NOTICE: event-43 провожу авторизацию панели id_dev=149, id_ctrl=39,  baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:15 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:15 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:30:15 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:30:15 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:15 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:15 --- NOTICE: 17:30:15 ev- 137 работа с контроллером 10.200.15.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:15 --- NOTICE: ev=34 Начало работы с панелью 10.200.12.4, id_dev= 182, device="1.2 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:15 --- NOTICE: #43 Панель 10.200.12.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:15 --- NOTICE: event-43 провожу авторизацию панели id_dev=182, id_ctrl=50,  baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:15 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:16 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:30:16 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:30:16 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:16 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:16 --- NOTICE: 17:30:16 ev- 137 работа с контроллером 10.200.12.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:30:16 --- NOTICE: event-142 stop minion basgetevent.php. Выборка событий завершена. Время выполнения timeExecute=9.0108201503754 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:03 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.20.2, id_dev= 101 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:03 --- NOTICE: rw=37 Панель 10.200.20.2 на связи 1, aa12fb, 1.9.0 20230928, 3.22.1, 2.10.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:03 --- NOTICE: 17:35:03 rw- 137 работа с контроллером 10.200.20.2 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.32.3, id_dev= 110 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: rw=37 Панель 10.200.32.3 на связи 1, aa12b, 1.8.0 20210129, 3.10.0, 2.0.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 9 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 71 Валидация номера карты прошла успешно in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 56 результат выполнения команды запись карты в 10.200.32.3. Ответ: <pre class="debug"><small>array</small><span>(2)</span> <span>(
    "status" => <small>integer</small> 400
    "res" => <small>array</small><span>(1)</span> <span>(
        "error" => <small>string</small><span>(50)</span> "Identifier with that type and number already exist"
    )</span>
)</span></pre> Данные команды для записи карты <pre class="debug"><small>array</small><span>(4)</span> <span>(
    "ID_CARDINDEV" => <small>string</small><span>(6)</span> "955888"
    "ID_CARD" => <small>string</small><span>(8)</span> "15408069"
    "ID_DEV" => <small>string</small><span>(3)</span> "111"
    "OPERATION" => <small>string</small><span>(1)</span> "1"
)</span></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 62 Command destination:: writekey id_dev=111 IP 10.200.32.3,  key="15408069". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 91 Answer destination: writekey id_dev=111 IP 10.200.32.3,  key="15408069". Answer: 400 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 71 Валидация номера карты прошла успешно in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 56 результат выполнения команды запись карты в 10.200.32.3. Ответ: <pre class="debug"><small>array</small><span>(2)</span> <span>(
    "status" => <small>integer</small> 400
    "res" => <small>array</small><span>(1)</span> <span>(
        "error" => <small>string</small><span>(50)</span> "Identifier with that type and number already exist"
    )</span>
)</span></pre> Данные команды для записи карты <pre class="debug"><small>array</small><span>(4)</span> <span>(
    "ID_CARDINDEV" => <small>string</small><span>(6)</span> "955711"
    "ID_CARD" => <small>string</small><span>(8)</span> "14196596"
    "ID_DEV" => <small>string</small><span>(3)</span> "111"
    "OPERATION" => <small>string</small><span>(1)</span> "1"
)</span></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 62 Command destination:: writekey id_dev=111 IP 10.200.32.3,  key="14196596". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 91 Answer destination: writekey id_dev=111 IP 10.200.32.3,  key="14196596". Answer: 400 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 71 Валидация номера карты прошла успешно in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 56 результат выполнения команды запись карты в 10.200.32.3. Ответ: <pre class="debug"><small>array</small><span>(2)</span> <span>(
    "status" => <small>integer</small> 400
    "res" => <small>array</small><span>(1)</span> <span>(
        "error" => <small>string</small><span>(50)</span> "Identifier with that type and number already exist"
    )</span>
)</span></pre> Данные команды для записи карты <pre class="debug"><small>array</small><span>(4)</span> <span>(
    "ID_CARDINDEV" => <small>string</small><span>(6)</span> "955858"
    "ID_CARD" => <small>string</small><span>(7)</span> "4118055"
    "ID_DEV" => <small>string</small><span>(3)</span> "111"
    "OPERATION" => <small>string</small><span>(1)</span> "1"
)</span></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 62 Command destination:: writekey id_dev=111 IP 10.200.32.3,  key="4118055". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 91 Answer destination: writekey id_dev=111 IP 10.200.32.3,  key="4118055". Answer: 400 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 71 Валидация номера карты прошла успешно in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 56 результат выполнения команды запись карты в 10.200.32.3. Ответ: <pre class="debug"><small>array</small><span>(2)</span> <span>(
    "status" => <small>integer</small> 400
    "res" => <small>array</small><span>(1)</span> <span>(
        "error" => <small>string</small><span>(50)</span> "Identifier with that type and number already exist"
    )</span>
)</span></pre> Данные команды для записи карты <pre class="debug"><small>array</small><span>(4)</span> <span>(
    "ID_CARDINDEV" => <small>string</small><span>(6)</span> "956457"
    "ID_CARD" => <small>string</small><span>(8)</span> "16093866"
    "ID_DEV" => <small>string</small><span>(3)</span> "111"
    "OPERATION" => <small>string</small><span>(1)</span> "1"
)</span></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 62 Command destination:: writekey id_dev=111 IP 10.200.32.3,  key="16093866". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 91 Answer destination: writekey id_dev=111 IP 10.200.32.3,  key="16093866". Answer: 400 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 71 Валидация номера карты прошла успешно in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 56 результат выполнения команды запись карты в 10.200.32.3. Ответ: <pre class="debug"><small>array</small><span>(2)</span> <span>(
    "status" => <small>integer</small> 400
    "res" => <small>array</small><span>(1)</span> <span>(
        "error" => <small>string</small><span>(50)</span> "Identifier with that type and number already exist"
    )</span>
)</span></pre> Данные команды для записи карты <pre class="debug"><small>array</small><span>(4)</span> <span>(
    "ID_CARDINDEV" => <small>string</small><span>(6)</span> "956725"
    "ID_CARD" => <small>string</small><span>(8)</span> "16081484"
    "ID_DEV" => <small>string</small><span>(3)</span> "111"
    "OPERATION" => <small>string</small><span>(1)</span> "1"
)</span></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 62 Command destination:: writekey id_dev=111 IP 10.200.32.3,  key="16081484". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 91 Answer destination: writekey id_dev=111 IP 10.200.32.3,  key="16081484". Answer: 400 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 71 Валидация номера карты прошла успешно in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 56 результат выполнения команды запись карты в 10.200.32.3. Ответ: <pre class="debug"><small>array</small><span>(2)</span> <span>(
    "status" => <small>integer</small> 400
    "res" => <small>array</small><span>(1)</span> <span>(
        "error" => <small>string</small><span>(50)</span> "Identifier with that type and number already exist"
    )</span>
)</span></pre> Данные команды для записи карты <pre class="debug"><small>array</small><span>(4)</span> <span>(
    "ID_CARDINDEV" => <small>string</small><span>(6)</span> "956792"
    "ID_CARD" => <small>string</small><span>(8)</span> "16079749"
    "ID_DEV" => <small>string</small><span>(3)</span> "111"
    "OPERATION" => <small>string</small><span>(1)</span> "1"
)</span></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 62 Command destination:: writekey id_dev=111 IP 10.200.32.3,  key="16079749". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 91 Answer destination: writekey id_dev=111 IP 10.200.32.3,  key="16079749". Answer: 400 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 71 Валидация номера карты прошла успешно in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 56 результат выполнения команды запись карты в 10.200.32.3. Ответ: <pre class="debug"><small>array</small><span>(2)</span> <span>(
    "status" => <small>integer</small> 400
    "res" => <small>array</small><span>(1)</span> <span>(
        "error" => <small>string</small><span>(50)</span> "Identifier with that type and number already exist"
    )</span>
)</span></pre> Данные команды для записи карты <pre class="debug"><small>array</small><span>(4)</span> <span>(
    "ID_CARDINDEV" => <small>string</small><span>(6)</span> "956859"
    "ID_CARD" => <small>string</small><span>(8)</span> "16104318"
    "ID_DEV" => <small>string</small><span>(3)</span> "111"
    "OPERATION" => <small>string</small><span>(1)</span> "1"
)</span></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 62 Command destination:: writekey id_dev=111 IP 10.200.32.3,  key="16104318". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 91 Answer destination: writekey id_dev=111 IP 10.200.32.3,  key="16104318". Answer: 400 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 17:35:04 rw- 137 работа с контроллером 10.200.32.3 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.12.4, id_dev= 182 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: rw=37 Панель 10.200.12.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:05 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:05 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:05 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:05 --- NOTICE: 17:35:05 rw- 137 работа с контроллером 10.200.12.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:05 --- NOTICE: 142 stop minion basrwrfid.php. timeExecute=1.7825801372528 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:06 --- NOTICE: event-14 start basgetevent.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:16 --- NOTICE: ev=34 Начало работы с панелью 10.200.20.2, id_dev= 101, device="2.1 Вест". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:16 --- NOTICE: #43 Панель 10.200.20.2 на связи 1, aa12fb, 1.9.0 20230928, 3.22.1, 2.10.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:16 --- NOTICE: event-43 провожу авторизацию панели id_dev=101, id_ctrl=25,  baseurl=10.200.20.2,  name='2.1 Вест' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:16 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:16 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:35:16 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 17:25:16 (1711380316697) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:35:21 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:21 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:21 --- NOTICE: 17:35:21 ev- 137 работа с контроллером 10.200.20.2 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:21 --- NOTICE: ev=34 Начало работы с панелью 10.200.32.3, id_dev= 110, device="2.4 Вест". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:21 --- NOTICE: #43 Панель 10.200.32.3 на связи 1, aa12b, 1.8.0 20210129, 3.10.0, 2.0.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:21 --- NOTICE: event-43 провожу авторизацию панели id_dev=110, id_ctrl=28,  baseurl=10.200.32.3,  name='2.4 Вест' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:21 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:21 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:35:21 --- NOTICE: #545 Получение событий начиная с метки 19.03.2024 18:49:11 (1710866951503) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:35:21 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 50 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:21 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:21, DeviceDate=#19.03.2024 20:26:36, EventCode=49, Door=0, EventIndex=1710872796139 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:21 --- NOTICE: event-87 Дверь открыта картой 9793240 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:21 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:21#, DeviceDate=#19.03.2024 20:32:39#, EventCode=50, Door=0, EventIndex=1710873159685, Card="9793240" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:21 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:21, DeviceDate=#19.03.2024 20:34:34, EventCode=49, Door=0, EventIndex=1710873274025 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:21 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:21, DeviceDate=#19.03.2024 20:35:21, EventCode=49, Door=0, EventIndex=1710873321801 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:21 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:21, DeviceDate=#19.03.2024 20:35:52, EventCode=49, Door=0, EventIndex=1710873352065 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:21 --- NOTICE: event-87 Дверь открыта картой 3530279 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:21 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:21#, DeviceDate=#19.03.2024 20:37:08#, EventCode=50, Door=0, EventIndex=1710873428252, Card="3530279" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:21 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:21, DeviceDate=#19.03.2024 20:37:46, EventCode=49, Door=0, EventIndex=1710873466364 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:21 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710873498219
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:21 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710873498469
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:21 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:21, DeviceDate=#19.03.2024 20:40:03, EventCode=49, Door=0, EventIndex=1710873603075 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:21 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710873717865
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:21 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710873718008
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:22, DeviceDate=#19.03.2024 20:42:25, EventCode=49, Door=0, EventIndex=1710873745491 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: event-87 Дверь открыта картой 8105360 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:22#, DeviceDate=#19.03.2024 20:44:07#, EventCode=50, Door=0, EventIndex=1710873847553, Card="8105360" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:22, DeviceDate=#19.03.2024 20:44:55, EventCode=49, Door=0, EventIndex=1710873895591 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:22, DeviceDate=#19.03.2024 20:44:57, EventCode=49, Door=0, EventIndex=1710873897459 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:22, DeviceDate=#19.03.2024 20:49:09, EventCode=49, Door=0, EventIndex=1710874149972 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: event-87 Дверь открыта картой 9793475 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:22#, DeviceDate=#19.03.2024 20:50:49#, EventCode=50, Door=0, EventIndex=1710874249006, Card="9793475" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: event-87 Дверь открыта картой 12449150 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:22#, DeviceDate=#19.03.2024 21:07:46#, EventCode=50, Door=0, EventIndex=1710875266520, Card="12449150" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: event-87 Дверь открыта картой 2539109 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:22#, DeviceDate=#19.03.2024 21:13:53#, EventCode=50, Door=0, EventIndex=1710875633261, Card="2539109" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:22, DeviceDate=#19.03.2024 21:17:30, EventCode=49, Door=0, EventIndex=1710875850739 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:22, DeviceDate=#19.03.2024 21:24:22, EventCode=49, Door=0, EventIndex=1710876262942 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: event-87 Дверь открыта картой 3530279 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:22#, DeviceDate=#19.03.2024 21:27:17#, EventCode=50, Door=0, EventIndex=1710876437681, Card="3530279" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: event-87 Дверь открыта картой 9837135 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:22#, DeviceDate=#19.03.2024 21:34:12#, EventCode=50, Door=0, EventIndex=1710876852684, Card="9837135" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: event-87 Дверь открыта картой 9837135 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:22#, DeviceDate=#19.03.2024 21:35:55#, EventCode=50, Door=0, EventIndex=1710876955573, Card="9837135" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710877200894
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710877201155
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:22, DeviceDate=#19.03.2024 21:44:39, EventCode=49, Door=0, EventIndex=1710877479504 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: event-87 Дверь открыта картой 15526488 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:22#, DeviceDate=#19.03.2024 21:46:50#, EventCode=50, Door=0, EventIndex=1710877610446, Card="15526488" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:22, DeviceDate=#19.03.2024 22:06:07, EventCode=49, Door=0, EventIndex=1710878767850 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: event-87 Дверь открыта картой 3530279 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:22#, DeviceDate=#19.03.2024 22:09:08#, EventCode=50, Door=0, EventIndex=1710878948263, Card="3530279" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: event-87 Дверь открыта картой 8280247 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:22#, DeviceDate=#19.03.2024 22:27:31#, EventCode=50, Door=0, EventIndex=1710880051715, Card="8280247" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710880071481
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710880071751
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:22, DeviceDate=#19.03.2024 22:38:56, EventCode=90, Door=0, EventIndex=1710880736419 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:22, DeviceDate=#19.03.2024 22:39:36, EventCode=49, Door=0, EventIndex=1710880776491 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: event-87 Дверь открыта картой 8105323 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:22#, DeviceDate=#19.03.2024 22:40:51#, EventCode=50, Door=0, EventIndex=1710880851711, Card="8105323" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: event-87 Дверь открыта картой 3530279 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:22#, DeviceDate=#19.03.2024 22:42:29#, EventCode=50, Door=0, EventIndex=1710880949864, Card="3530279" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: event-87 Дверь открыта картой 6264831 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:22#, DeviceDate=#19.03.2024 23:01:48#, EventCode=50, Door=0, EventIndex=1710882108099, Card="6264831" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:23 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:23, DeviceDate=#19.03.2024 23:04:33, EventCode=49, Door=0, EventIndex=1710882273619 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:23 --- NOTICE: event-87 Дверь открыта картой 3530279 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:23 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:23#, DeviceDate=#19.03.2024 23:08:00#, EventCode=50, Door=0, EventIndex=1710882480700, Card="3530279" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:23 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:23, DeviceDate=#19.03.2024 23:42:56, EventCode=49, Door=0, EventIndex=1710884576216 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:23 --- NOTICE: event-87 Дверь открыта картой 3530279 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:23 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:23#, DeviceDate=#19.03.2024 23:46:20#, EventCode=50, Door=0, EventIndex=1710884780525, Card="3530279" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:23 --- NOTICE: event-87 Дверь открыта картой 8105288 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:23 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:23#, DeviceDate=#19.03.2024 23:49:27#, EventCode=50, Door=0, EventIndex=1710884967828, Card="8105288" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:23 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:23, DeviceDate=#19.03.2024 23:51:32, EventCode=49, Door=0, EventIndex=1710885092062 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:23 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:23, DeviceDate=#19.03.2024 23:51:35, EventCode=49, Door=0, EventIndex=1710885095481 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:23 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:23, DeviceDate=#19.03.2024 23:51:56, EventCode=49, Door=0, EventIndex=1710885116701 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:23 --- NOTICE: event-87 Дверь открыта картой 10183783 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:23 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:35:23#, DeviceDate=#19.03.2024 23:54:38#, EventCode=50, Door=0, EventIndex=1710885278227, Card="10183783" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:23 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710886825569
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:23 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710886825632
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:23 --- NOTICE: 17:35:23 ev- 137 работа с контроллером 10.200.32.3 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:23 --- NOTICE: ev=34 Начало работы с панелью 10.200.15.4, id_dev= 149, device="1.5 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:23 --- NOTICE: #43 Панель 10.200.15.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:23 --- NOTICE: event-43 провожу авторизацию панели id_dev=149, id_ctrl=39,  baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:23 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:23 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:35:23 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:35:23 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:23 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:23 --- NOTICE: 17:35:23 ev- 137 работа с контроллером 10.200.15.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:24 --- NOTICE: ev=34 Начало работы с панелью 10.200.12.4, id_dev= 182, device="1.2 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:24 --- NOTICE: #43 Панель 10.200.12.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:24 --- NOTICE: event-43 провожу авторизацию панели id_dev=182, id_ctrl=50,  baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:24 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:24 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:35:24 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:35:24 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:24 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:24 --- NOTICE: 17:35:24 ev- 137 работа с контроллером 10.200.12.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:35:24 --- NOTICE: event-142 stop minion basgetevent.php. Выборка событий завершена. Время выполнения timeExecute=17.47930598259 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:09 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.20.2, id_dev= 101 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:09 --- NOTICE: rw=37 Панель 10.200.20.2 на связи 1, aa12fb, 1.9.0 20230928, 3.22.1, 2.10.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:09 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:09 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:09 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:09 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:09 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:09 --- NOTICE: 17:40:09 rw- 137 работа с контроллером 10.200.20.2 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:09 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.32.3, id_dev= 110 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:09 --- NOTICE: rw=37 Панель 10.200.32.3 на связи 1, aa12b, 1.8.0 20210129, 3.10.0, 2.0.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:09 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:09 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:09 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:09 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:09 --- NOTICE: 17:40:09 rw- 137 работа с контроллером 10.200.32.3 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:10 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.12.4, id_dev= 182 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:10 --- NOTICE: rw=37 Панель 10.200.12.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:10 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:10 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:10 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:10 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:10 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:10 --- NOTICE: 17:40:10 rw- 137 работа с контроллером 10.200.12.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:10 --- NOTICE: 142 stop minion basrwrfid.php. timeExecute=6.9178318977356 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:11 --- NOTICE: event-14 start basgetevent.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:12 --- NOTICE: ev=34 Начало работы с панелью 10.200.20.2, id_dev= 101, device="2.1 Вест". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:12 --- NOTICE: #43 Панель 10.200.20.2 на связи 1, aa12fb, 1.9.0 20230928, 3.22.1, 2.10.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:12 --- NOTICE: event-43 провожу авторизацию панели id_dev=101, id_ctrl=25,  baseurl=10.200.20.2,  name='2.1 Вест' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:12 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:40:12 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 17:25:16 (1711380316697) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:40:17 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:17 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:17 --- NOTICE: 17:40:17 ev- 137 работа с контроллером 10.200.20.2 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:17 --- NOTICE: ev=34 Начало работы с панелью 10.200.32.3, id_dev= 110, device="2.4 Вест". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:17 --- NOTICE: #43 Панель 10.200.32.3 на связи 1, aa12b, 1.8.0 20210129, 3.10.0, 2.0.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:17 --- NOTICE: event-43 провожу авторизацию панели id_dev=110, id_ctrl=28,  baseurl=10.200.32.3,  name='2.4 Вест' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:17 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:17 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:40:17 --- NOTICE: #545 Получение событий начиная с метки 20.03.2024 00:20:25 (1710886825632) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:40:18 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 50 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18, DeviceDate=#20.03.2024 07:34:57, EventCode=49, Door=0, EventIndex=1710912897338 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18, DeviceDate=#20.03.2024 07:35:50, EventCode=49, Door=0, EventIndex=1710912950738 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: event-87 Дверь открыта картой 5156028 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18#, DeviceDate=#20.03.2024 07:36:44#, EventCode=50, Door=0, EventIndex=1710913004660, Card="5156028" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: event-87 Дверь открыта картой 8105350 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18#, DeviceDate=#20.03.2024 07:40:19#, EventCode=50, Door=0, EventIndex=1710913219317, Card="8105350" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: event-87 Дверь открыта картой 263512 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18#, DeviceDate=#20.03.2024 07:41:14#, EventCode=50, Door=0, EventIndex=1710913274987, Card="263512" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: event-87 Дверь открыта картой 12449150 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18#, DeviceDate=#20.03.2024 07:45:41#, EventCode=50, Door=0, EventIndex=1710913541965, Card="12449150" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18, DeviceDate=#20.03.2024 07:45:43, EventCode=49, Door=0, EventIndex=1710913543727 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18, DeviceDate=#20.03.2024 07:46:33, EventCode=49, Door=0, EventIndex=1710913593288 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: event-87 Дверь открыта картой 3536977 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18#, DeviceDate=#20.03.2024 07:51:18#, EventCode=50, Door=0, EventIndex=1710913878042, Card="3536977" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: event-87 Дверь открыта картой 8105360 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18#, DeviceDate=#20.03.2024 07:51:54#, EventCode=50, Door=0, EventIndex=1710913914593, Card="8105360" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: event-87 Дверь открыта картой 4865814 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18#, DeviceDate=#20.03.2024 07:55:40#, EventCode=50, Door=0, EventIndex=1710914140262, Card="4865814" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18, DeviceDate=#20.03.2024 07:57:27, EventCode=49, Door=0, EventIndex=1710914247686 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: event-87 Дверь открыта картой 3536977 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18#, DeviceDate=#20.03.2024 08:00:47#, EventCode=50, Door=0, EventIndex=1710914447413, Card="3536977" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: event-87 Дверь открыта картой 756017 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18#, DeviceDate=#20.03.2024 08:01:13#, EventCode=50, Door=0, EventIndex=1710914473563, Card="756017" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18, DeviceDate=#20.03.2024 08:05:08, EventCode=49, Door=0, EventIndex=1710914708633 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18, DeviceDate=#20.03.2024 08:05:24, EventCode=49, Door=0, EventIndex=1710914724250 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18, DeviceDate=#20.03.2024 08:07:36, EventCode=49, Door=0, EventIndex=1710914856977 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18, DeviceDate=#20.03.2024 08:07:57, EventCode=49, Door=0, EventIndex=1710914877852 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18, DeviceDate=#20.03.2024 08:09:32, EventCode=49, Door=0, EventIndex=1710914972244 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: event-87 Дверь открыта картой 2156483 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18#, DeviceDate=#20.03.2024 08:09:34#, EventCode=50, Door=0, EventIndex=1710914974924, Card="2156483" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: event-87 Дверь открыта картой 3553233 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18#, DeviceDate=#20.03.2024 08:09:58#, EventCode=50, Door=0, EventIndex=1710914998866, Card="3553233" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18, DeviceDate=#20.03.2024 08:11:28, EventCode=49, Door=0, EventIndex=1710915088543 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18, DeviceDate=#20.03.2024 08:12:34, EventCode=49, Door=0, EventIndex=1710915154871 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18, DeviceDate=#20.03.2024 08:14:38, EventCode=49, Door=0, EventIndex=1710915278444 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18, DeviceDate=#20.03.2024 08:15:19, EventCode=49, Door=0, EventIndex=1710915319472 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: event-87 Дверь открыта картой 8105323 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18#, DeviceDate=#20.03.2024 08:18:19#, EventCode=50, Door=0, EventIndex=1710915499342, Card="8105323" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18, DeviceDate=#20.03.2024 08:21:19, EventCode=49, Door=0, EventIndex=1710915679424 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18, DeviceDate=#20.03.2024 08:22:06, EventCode=49, Door=0, EventIndex=1710915726037 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:18 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:18, DeviceDate=#20.03.2024 08:22:26, EventCode=90, Door=0, EventIndex=1710915746597 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:19, DeviceDate=#20.03.2024 08:23:34, EventCode=49, Door=0, EventIndex=1710915814913 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710916154622
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(29)</span> "access_denied_by_unknown_card"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710916158138
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(29)</span> "access_denied_by_unknown_card"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710916162429
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(29)</span> "access_denied_by_unknown_card"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710916165591
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(29)</span> "access_denied_by_unknown_card"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:19, DeviceDate=#20.03.2024 08:29:36, EventCode=49, Door=0, EventIndex=1710916176880 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:19, DeviceDate=#20.03.2024 08:34:35, EventCode=49, Door=0, EventIndex=1710916475799 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: event-87 Дверь открыта картой 5253488 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:19#, DeviceDate=#20.03.2024 08:40:26#, EventCode=50, Door=0, EventIndex=1710916826899, Card="5253488" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:19, DeviceDate=#20.03.2024 08:41:08, EventCode=49, Door=0, EventIndex=1710916868642 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:19, DeviceDate=#20.03.2024 08:41:30, EventCode=49, Door=0, EventIndex=1710916890154 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:19, DeviceDate=#20.03.2024 08:42:45, EventCode=49, Door=0, EventIndex=1710916965375 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: event-87 Дверь открыта картой 15749631 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:19#, DeviceDate=#20.03.2024 08:47:10#, EventCode=50, Door=0, EventIndex=1710917230076, Card="15749631" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: event-87 Дверь открыта картой 2539109 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:19#, DeviceDate=#20.03.2024 08:50:23#, EventCode=50, Door=0, EventIndex=1710917423138, Card="2539109" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:19, DeviceDate=#20.03.2024 09:01:58, EventCode=49, Door=0, EventIndex=1710918118292 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:19, DeviceDate=#20.03.2024 09:03:46, EventCode=49, Door=0, EventIndex=1710918226927 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: event-87 Дверь открыта картой 8105272 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:19#, DeviceDate=#20.03.2024 09:06:03#, EventCode=50, Door=0, EventIndex=1710918363834, Card="8105272" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710918592158
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(29)</span> "access_denied_by_unknown_card"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: event-87 Дверь открыта картой 5905265 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:19#, DeviceDate=#20.03.2024 09:09:52#, EventCode=50, Door=0, EventIndex=1710918592236, Card="5905265" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:19, DeviceDate=#20.03.2024 09:10:59, EventCode=49, Door=0, EventIndex=1710918659734 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:40:19, DeviceDate=#20.03.2024 09:17:54, EventCode=90, Door=0, EventIndex=1710919074601 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710919144143
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: 17:40:19 ev- 137 работа с контроллером 10.200.32.3 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: ev=34 Начало работы с панелью 10.200.15.4, id_dev= 149, device="1.5 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: #43 Панель 10.200.15.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: event-43 провожу авторизацию панели id_dev=149, id_ctrl=39,  baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:19 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:40:19 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:40:20 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:20 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:20 --- NOTICE: 17:40:20 ev- 137 работа с контроллером 10.200.15.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:20 --- NOTICE: ev=34 Начало работы с панелью 10.200.12.4, id_dev= 182, device="1.2 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:20 --- NOTICE: #43 Панель 10.200.12.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:20 --- NOTICE: event-43 провожу авторизацию панели id_dev=182, id_ctrl=50,  baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:20 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:20 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:40:20 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:40:20 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:20 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:20 --- NOTICE: 17:40:20 ev- 137 работа с контроллером 10.200.12.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:40:20 --- NOTICE: event-142 stop minion basgetevent.php. Выборка событий завершена. Время выполнения timeExecute=8.7504961490631 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:03 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.20.2, id_dev= 101 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:03 --- NOTICE: rw=37 Панель 10.200.20.2 на связи 1, aa12fb, 1.9.0 20230928, 3.22.1, 2.10.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:04 --- NOTICE: 17:45:04 rw- 137 работа с контроллером 10.200.20.2 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:04 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.32.3, id_dev= 110 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:04 --- NOTICE: rw=37 Панель 10.200.32.3 на связи 1, aa12b, 1.8.0 20210129, 3.10.0, 2.0.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:04 --- NOTICE: 17:45:04 rw- 137 работа с контроллером 10.200.32.3 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:04 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.12.4, id_dev= 182 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:04 --- NOTICE: rw=37 Панель 10.200.12.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:04 --- NOTICE: 17:45:04 rw- 137 работа с контроллером 10.200.12.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:04 --- NOTICE: 142 stop minion basrwrfid.php. timeExecute=1.0962221622467 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:05 --- NOTICE: event-14 start basgetevent.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:06 --- NOTICE: ev=34 Начало работы с панелью 10.200.20.2, id_dev= 101, device="2.1 Вест". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:06 --- NOTICE: #43 Панель 10.200.20.2 на связи 1, aa12fb, 1.9.0 20230928, 3.22.1, 2.10.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:06 --- NOTICE: event-43 провожу авторизацию панели id_dev=101, id_ctrl=25,  baseurl=10.200.20.2,  name='2.1 Вест' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:06 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:45:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 17:25:16 (1711380316697) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:45:12 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:12 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:12 --- NOTICE: 17:45:12 ev- 137 работа с контроллером 10.200.20.2 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:12 --- NOTICE: ev=34 Начало работы с панелью 10.200.32.3, id_dev= 110, device="2.4 Вест". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:12 --- NOTICE: #43 Панель 10.200.32.3 на связи 1, aa12b, 1.8.0 20210129, 3.10.0, 2.0.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:12 --- NOTICE: event-43 провожу авторизацию панели id_dev=110, id_ctrl=28,  baseurl=10.200.32.3,  name='2.4 Вест' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:12 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:45:12 --- NOTICE: #545 Получение событий начиная с метки 20.03.2024 09:19:04 (1710919144143) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:45:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 50 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:12 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:12, DeviceDate=#20.03.2024 12:12:04, EventCode=49, Door=0, EventIndex=1710929524226 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:12 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:12, DeviceDate=#20.03.2024 12:15:03, EventCode=49, Door=0, EventIndex=1710929703097 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:12 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:12, DeviceDate=#20.03.2024 12:16:01, EventCode=90, Door=0, EventIndex=1710929761649 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:12 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:12, DeviceDate=#20.03.2024 12:18:08, EventCode=49, Door=0, EventIndex=1710929888476 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:12 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:12, DeviceDate=#20.03.2024 12:20:28, EventCode=49, Door=0, EventIndex=1710930028570 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:12 --- NOTICE: event-87 Дверь открыта картой 15526488 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:12 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:12#, DeviceDate=#20.03.2024 12:21:49#, EventCode=50, Door=0, EventIndex=1710930109642, Card="15526488" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:13, DeviceDate=#20.03.2024 12:22:08, EventCode=49, Door=0, EventIndex=1710930128550 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: event-87 Дверь открыта картой 14754471 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:13#, DeviceDate=#20.03.2024 12:24:52#, EventCode=50, Door=0, EventIndex=1710930292387, Card="14754471" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:13, DeviceDate=#20.03.2024 12:25:49, EventCode=49, Door=0, EventIndex=1710930349582 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:13, DeviceDate=#20.03.2024 12:27:06, EventCode=49, Door=0, EventIndex=1710930426720 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:13, DeviceDate=#20.03.2024 12:30:24, EventCode=49, Door=0, EventIndex=1710930624517 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: event-87 Дверь открыта картой 4124101 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:13#, DeviceDate=#20.03.2024 12:33:42#, EventCode=50, Door=0, EventIndex=1710930822815, Card="4124101" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:13, DeviceDate=#20.03.2024 12:34:25, EventCode=49, Door=0, EventIndex=1710930865389 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710930916086
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710930916337
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:13, DeviceDate=#20.03.2024 12:37:03, EventCode=90, Door=0, EventIndex=1710931023469 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:13, DeviceDate=#20.03.2024 12:38:50, EventCode=49, Door=0, EventIndex=1710931130294 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:13, DeviceDate=#20.03.2024 12:44:31, EventCode=49, Door=0, EventIndex=1710931471180 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:13, DeviceDate=#20.03.2024 12:46:53, EventCode=49, Door=0, EventIndex=1710931613516 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:13, DeviceDate=#20.03.2024 12:49:05, EventCode=49, Door=0, EventIndex=1710931745199 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:13, DeviceDate=#20.03.2024 12:54:26, EventCode=49, Door=0, EventIndex=1710932066100 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: event-87 Дверь открыта картой 14754471 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:13#, DeviceDate=#20.03.2024 12:55:08#, EventCode=50, Door=0, EventIndex=1710932108282, Card="14754471" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:13, DeviceDate=#20.03.2024 12:57:53, EventCode=49, Door=0, EventIndex=1710932273366 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:13, DeviceDate=#20.03.2024 12:58:51, EventCode=49, Door=0, EventIndex=1710932331491 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:13, DeviceDate=#20.03.2024 13:00:37, EventCode=49, Door=0, EventIndex=1710932437296 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:13, DeviceDate=#20.03.2024 13:04:01, EventCode=49, Door=0, EventIndex=1710932641837 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:13, DeviceDate=#20.03.2024 13:07:59, EventCode=49, Door=0, EventIndex=1710932879014 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:13, DeviceDate=#20.03.2024 13:08:11, EventCode=49, Door=0, EventIndex=1710932891949 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:13, DeviceDate=#20.03.2024 13:11:13, EventCode=49, Door=0, EventIndex=1710933073192 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:13, DeviceDate=#20.03.2024 13:28:49, EventCode=90, Door=0, EventIndex=1710934129283 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710934688168
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710934688313
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710934688985
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710934689658
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710934690377
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:13 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710934691032
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710934695089
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710934695346
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:14, DeviceDate=#20.03.2024 13:39:37, EventCode=49, Door=0, EventIndex=1710934777710 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:14, DeviceDate=#20.03.2024 14:18:46, EventCode=49, Door=0, EventIndex=1710937126579 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: event-87 Дверь открыта картой 14754471 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:14#, DeviceDate=#20.03.2024 14:20:36#, EventCode=50, Door=0, EventIndex=1710937236717, Card="14754471" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:14, DeviceDate=#20.03.2024 14:28:29, EventCode=49, Door=0, EventIndex=1710937709947 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: event-87 Дверь открыта картой 3536977 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:14#, DeviceDate=#20.03.2024 14:30:34#, EventCode=50, Door=0, EventIndex=1710937834293, Card="3536977" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: event-87 Дверь открыта картой 6264831 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:14#, DeviceDate=#20.03.2024 14:34:02#, EventCode=50, Door=0, EventIndex=1710938042737, Card="6264831" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:14, DeviceDate=#20.03.2024 14:34:39, EventCode=49, Door=0, EventIndex=1710938079672 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: event-87 Дверь открыта картой 9793475 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:14#, DeviceDate=#20.03.2024 14:36:45#, EventCode=50, Door=0, EventIndex=1710938205731, Card="9793475" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:14, DeviceDate=#20.03.2024 14:37:42, EventCode=49, Door=0, EventIndex=1710938262616 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: event-87 Дверь открыта картой 5532645 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:14#, DeviceDate=#20.03.2024 14:40:08#, EventCode=50, Door=0, EventIndex=1710938408447, Card="5532645" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:14, DeviceDate=#20.03.2024 14:40:50, EventCode=49, Door=0, EventIndex=1710938450449 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: event-87 Дверь открыта картой 8105349 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:45:14#, DeviceDate=#20.03.2024 14:43:31#, EventCode=50, Door=0, EventIndex=1710938611506, Card="8105349" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: 17:45:14 ev- 137 работа с контроллером 10.200.32.3 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: ev=34 Начало работы с панелью 10.200.15.4, id_dev= 149, device="1.5 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: #43 Панель 10.200.15.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: event-43 провожу авторизацию панели id_dev=149, id_ctrl=39,  baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:45:14 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:45:14 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: 17:45:14 ev- 137 работа с контроллером 10.200.15.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: ev=34 Начало работы с панелью 10.200.12.4, id_dev= 182, device="1.2 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:14 --- NOTICE: #43 Панель 10.200.12.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:15 --- NOTICE: event-43 провожу авторизацию панели id_dev=182, id_ctrl=50,  baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:15 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:15 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:45:15 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:45:15 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:15 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:15 --- NOTICE: 17:45:15 ev- 137 работа с контроллером 10.200.12.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:45:15 --- NOTICE: event-142 stop minion basgetevent.php. Выборка событий завершена. Время выполнения timeExecute=9.3188869953156 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:27 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:27 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.20.2, id_dev= 101 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:27 --- NOTICE: rw=37 Панель 10.200.20.2 на связи 1, aa12fb, 1.9.0 20230928, 3.22.1, 2.10.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:27 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:27 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:27 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:27 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:27 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:27 --- NOTICE: 17:50:27 rw- 137 работа с контроллером 10.200.20.2 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:28 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.32.3, id_dev= 110 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:28 --- NOTICE: rw=37 Панель 10.200.32.3 на связи 1, aa12b, 1.8.0 20210129, 3.10.0, 2.0.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:28 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:28 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:28 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:28 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:28 --- NOTICE: 17:50:28 rw- 137 работа с контроллером 10.200.32.3 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:28 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.12.4, id_dev= 182 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:28 --- NOTICE: rw=37 Панель 10.200.12.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:28 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:28 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:28 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:28 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:28 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:28 --- NOTICE: 17:50:28 rw- 137 работа с контроллером 10.200.12.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:28 --- NOTICE: 142 stop minion basrwrfid.php. timeExecute=1.2037100791931 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:29 --- NOTICE: event-14 start basgetevent.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:30 --- NOTICE: ev=34 Начало работы с панелью 10.200.20.2, id_dev= 101, device="2.1 Вест". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:30 --- NOTICE: #43 Панель 10.200.20.2 на связи 1, aa12fb, 1.9.0 20230928, 3.22.1, 2.10.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:30 --- NOTICE: event-43 провожу авторизацию панели id_dev=101, id_ctrl=25,  baseurl=10.200.20.2,  name='2.1 Вест' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:30 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:30 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:50:30 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 17:25:16 (1711380316697) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:50:35 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:35 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:35 --- NOTICE: 17:50:35 ev- 137 работа с контроллером 10.200.20.2 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:36 --- NOTICE: ev=34 Начало работы с панелью 10.200.32.3, id_dev= 110, device="2.4 Вест". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:36 --- NOTICE: #43 Панель 10.200.32.3 на связи 1, aa12b, 1.8.0 20210129, 3.10.0, 2.0.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:36 --- NOTICE: event-43 провожу авторизацию панели id_dev=110, id_ctrl=28,  baseurl=10.200.32.3,  name='2.4 Вест' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:36 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:36 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:50:36 --- NOTICE: #545 Получение событий начиная с метки 20.03.2024 14:43:31 (1710938611506) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:50:36 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 50 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:36 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:50:36, DeviceDate=#20.03.2024 16:59:47, EventCode=90, Door=0, EventIndex=1710946787861 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:36 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:50:36, DeviceDate=#20.03.2024 17:01:21, EventCode=49, Door=0, EventIndex=1710946881014 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:36 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:50:36, DeviceDate=#20.03.2024 17:04:01, EventCode=49, Door=0, EventIndex=1710947041451 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:36 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:50:36, DeviceDate=#20.03.2024 17:05:13, EventCode=49, Door=0, EventIndex=1710947113426 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:36 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710947144551
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:36 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710947144810
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:36 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:50:36, DeviceDate=#20.03.2024 17:06:23, EventCode=49, Door=0, EventIndex=1710947183207 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:36 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:50:36, DeviceDate=#20.03.2024 17:08:02, EventCode=49, Door=0, EventIndex=1710947282577 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:36 --- NOTICE: event-87 Дверь открыта картой 5532645 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:36 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:50:36#, DeviceDate=#20.03.2024 17:09:09#, EventCode=50, Door=0, EventIndex=1710947349586, Card="5532645" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:36 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:50:36, DeviceDate=#20.03.2024 17:09:39, EventCode=49, Door=0, EventIndex=1710947379859 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:36 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:50:36, DeviceDate=#20.03.2024 17:13:41, EventCode=49, Door=0, EventIndex=1710947621525 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:36 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:50:36, DeviceDate=#20.03.2024 17:18:01, EventCode=49, Door=0, EventIndex=1710947881400 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:36 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:50:36, DeviceDate=#20.03.2024 17:19:27, EventCode=90, Door=0, EventIndex=1710947967743 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:36 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:50:36, DeviceDate=#20.03.2024 17:19:41, EventCode=49, Door=0, EventIndex=1710947981882 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:36 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:50:36, DeviceDate=#20.03.2024 17:21:26, EventCode=90, Door=0, EventIndex=1710948086491 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:36 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:50:36, DeviceDate=#20.03.2024 17:26:04, EventCode=90, Door=0, EventIndex=1710948364812 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:36 --- NOTICE: event-87 Дверь открыта картой 6799382 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:36 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:50:36#, DeviceDate=#20.03.2024 17:29:39#, EventCode=50, Door=0, EventIndex=1710948579131, Card="6799382" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:36 --- NOTICE: event-87 Дверь открыта картой 721006 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:36 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:50:36#, DeviceDate=#20.03.2024 17:29:39#, EventCode=50, Door=0, EventIndex=1710948579332, Card="721006" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-87 Дверь открыта картой 3536977 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:50:37#, DeviceDate=#20.03.2024 17:38:39#, EventCode=50, Door=0, EventIndex=1710949119391, Card="3536977" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:50:37, DeviceDate=#20.03.2024 17:41:27, EventCode=49, Door=0, EventIndex=1710949287439 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-87 Дверь открыта картой 13090060 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:50:37#, DeviceDate=#20.03.2024 17:42:33#, EventCode=50, Door=0, EventIndex=1710949353457, Card="13090060" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-87 Дверь открыта картой 5253488 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:50:37#, DeviceDate=#20.03.2024 17:43:34#, EventCode=50, Door=0, EventIndex=1710949414280, Card="5253488" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-87 Дверь открыта картой 8105344 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:50:37#, DeviceDate=#20.03.2024 17:45:54#, EventCode=50, Door=0, EventIndex=1710949554801, Card="8105344" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-87 Дверь открыта картой 8105344 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:50:37#, DeviceDate=#20.03.2024 17:50:30#, EventCode=50, Door=0, EventIndex=1710949830956, Card="8105344" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710949885299
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710949885555
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710949885872
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:50:37, DeviceDate=#20.03.2024 17:54:50, EventCode=49, Door=0, EventIndex=1710950090760 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710950236945
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710950237197
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-87 Дверь открыта картой 1376468 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:50:37#, DeviceDate=#20.03.2024 17:58:01#, EventCode=50, Door=0, EventIndex=1710950281894, Card="1376468" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710950332914
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710950333166
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-87 Дверь открыта картой 16164364 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:50:37#, DeviceDate=#20.03.2024 18:00:19#, EventCode=50, Door=0, EventIndex=1710950419963, Card="16164364" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710950785037
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710950785291
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710950786062
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710950786666
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710950787347
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710950787801
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710950980299
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710950980452
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710950980837
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710951112182
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710951112380
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710951112447
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:50:37, DeviceDate=#20.03.2024 18:12:18, EventCode=49, Door=0, EventIndex=1710951138458 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710951272833
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(26)</span> "access_granted_by_api_call"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710951638408
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710951638670
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: 17:50:37 ev- 137 работа с контроллером 10.200.32.3 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: ev=34 Начало работы с панелью 10.200.15.4, id_dev= 149, device="1.5 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: #43 Панель 10.200.15.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-43 провожу авторизацию панели id_dev=149, id_ctrl=39,  baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:50:37 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:50:37 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:37 --- NOTICE: 17:50:37 ev- 137 работа с контроллером 10.200.15.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:38 --- NOTICE: ev=34 Начало работы с панелью 10.200.12.4, id_dev= 182, device="1.2 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:38 --- NOTICE: #43 Панель 10.200.12.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:38 --- NOTICE: event-43 провожу авторизацию панели id_dev=182, id_ctrl=50,  baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:38 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:38 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:50:38 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:50:38 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:38 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:38 --- NOTICE: 17:50:38 ev- 137 работа с контроллером 10.200.12.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:50:38 --- NOTICE: event-142 stop minion basgetevent.php. Выборка событий завершена. Время выполнения timeExecute=8.3749558925629 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:06 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:11 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.20.2, id_dev= 101 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:11 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:11 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:11 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:11 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:11 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:11 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.32.3, id_dev= 110 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:11 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:11 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:11 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:11 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:11 --- NOTICE: 

rw=34 basrwrfid Начало работы с панелью 10.200.12.4, id_dev= 182 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:11 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:11 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:11 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:11 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:11 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:11 --- NOTICE: 142 stop minion basrwrfid.php. timeExecute=5.2242600917816 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:14 --- NOTICE: event-14 start basgetevent.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:15 --- NOTICE: ev=34 Начало работы с панелью 10.200.20.2, id_dev= 101, device="2.1 Вест". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:15 --- NOTICE: #43 Панель 10.200.20.2 на связи 1, aa12fb, 1.9.0 20230928, 3.22.1, 2.10.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:15 --- NOTICE: event-43 провожу авторизацию панели id_dev=101, id_ctrl=25,  baseurl=10.200.20.2,  name='2.1 Вест' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:15 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:15 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:55:15 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 17:25:16 (1711380316697) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:55:21 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:21 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:21 --- NOTICE: 17:55:21 ev- 137 работа с контроллером 10.200.20.2 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:21 --- NOTICE: ev=34 Начало работы с панелью 10.200.32.3, id_dev= 110, device="2.4 Вест". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:21 --- NOTICE: #43 Панель 10.200.32.3 на связи 1, aa12b, 1.8.0 20210129, 3.10.0, 2.0.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:21 --- NOTICE: event-43 провожу авторизацию панели id_dev=110, id_ctrl=28,  baseurl=10.200.32.3,  name='2.4 Вест' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:21 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:21 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:55:21 --- NOTICE: #545 Получение событий начиная с метки 20.03.2024 18:20:38 (1710951638670) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:55:21 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 50 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710956420749
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:22, DeviceDate=#20.03.2024 19:42:55, EventCode=49, Door=0, EventIndex=1710956575391 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: event-87 Дверь открыта картой 2559438 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:22#, DeviceDate=#20.03.2024 19:43:13#, EventCode=50, Door=0, EventIndex=1710956593099, Card="2559438" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:22, DeviceDate=#20.03.2024 19:45:10, EventCode=49, Door=0, EventIndex=1710956710675 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: event-87 Дверь открыта картой 8105350 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:22#, DeviceDate=#20.03.2024 19:47:54#, EventCode=50, Door=0, EventIndex=1710956874393, Card="8105350" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:22, DeviceDate=#20.03.2024 19:49:21, EventCode=90, Door=0, EventIndex=1710956961379 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: event-87 Дверь открыта картой 8105273 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:22#, DeviceDate=#20.03.2024 19:51:59#, EventCode=50, Door=0, EventIndex=1710957119575, Card="8105273" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:22, DeviceDate=#20.03.2024 19:57:20, EventCode=49, Door=0, EventIndex=1710957440189 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:22, DeviceDate=#20.03.2024 19:58:59, EventCode=49, Door=0, EventIndex=1710957539470 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710957588551
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710957588810
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:22, DeviceDate=#20.03.2024 20:02:32, EventCode=49, Door=0, EventIndex=1710957752573 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:22, DeviceDate=#20.03.2024 20:03:29, EventCode=49, Door=0, EventIndex=1710957809886 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:22, DeviceDate=#20.03.2024 20:10:16, EventCode=49, Door=0, EventIndex=1710958216149 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: event-87 Дверь открыта картой 3530279 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:22#, DeviceDate=#20.03.2024 20:13:12#, EventCode=50, Door=0, EventIndex=1710958392401, Card="3530279" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: event-87 Дверь открыта картой 11582482 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:22#, DeviceDate=#20.03.2024 20:13:31#, EventCode=50, Door=0, EventIndex=1710958411169, Card="11582482" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710958576091
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710958576158
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: event-87 Дверь открыта картой 8105336 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:22#, DeviceDate=#20.03.2024 20:18:33#, EventCode=50, Door=0, EventIndex=1710958713665, Card="8105336" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: event-87 Дверь открыта картой 9793711 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:22#, DeviceDate=#20.03.2024 20:28:37#, EventCode=50, Door=0, EventIndex=1710959317484, Card="9793711" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: event-87 Дверь открыта картой 5532645 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:22#, DeviceDate=#20.03.2024 20:30:03#, EventCode=50, Door=0, EventIndex=1710959403851, Card="5532645" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:22 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:22, DeviceDate=#20.03.2024 20:30:20, EventCode=49, Door=0, EventIndex=1710959420421 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:23 --- NOTICE: event-87 Дверь открыта картой 3530279 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:23 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:23#, DeviceDate=#20.03.2024 20:32:34#, EventCode=50, Door=0, EventIndex=1710959554750, Card="3530279" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:23 --- NOTICE: event-87 Дверь открыта картой 8105363 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:23 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:23#, DeviceDate=#20.03.2024 20:38:01#, EventCode=50, Door=0, EventIndex=1710959881865, Card="8105363" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:23 --- NOTICE: event-87 Дверь открыта картой 8105328 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:23 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:23#, DeviceDate=#20.03.2024 20:40:58#, EventCode=50, Door=0, EventIndex=1710960058697, Card="8105328" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:23 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:23, DeviceDate=#20.03.2024 20:49:24, EventCode=49, Door=0, EventIndex=1710960564867 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:23 --- NOTICE: event-87 Дверь открыта картой 3530279 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:23 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:23#, DeviceDate=#20.03.2024 20:51:59#, EventCode=50, Door=0, EventIndex=1710960719148, Card="3530279" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:23 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710960800046
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:23 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710960800110
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:23 --- NOTICE: event-87 Дверь открыта картой 9793240 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:23 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:23#, DeviceDate=#20.03.2024 20:55:33#, EventCode=50, Door=0, EventIndex=1710960933253, Card="9793240" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:23 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:23, DeviceDate=#20.03.2024 20:59:27, EventCode=49, Door=0, EventIndex=1710961167796 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:23 --- NOTICE: event-87 Дверь открыта картой 3530279 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:23 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:23#, DeviceDate=#20.03.2024 21:03:11#, EventCode=50, Door=0, EventIndex=1710961391629, Card="3530279" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:23 --- NOTICE: event-87 Дверь открыта картой 3530279 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:23 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:23#, DeviceDate=#20.03.2024 21:10:53#, EventCode=50, Door=0, EventIndex=1710961853379, Card="3530279" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:24 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710962006291
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:24 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710962006414
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:24 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:24, DeviceDate=#20.03.2024 21:17:06, EventCode=90, Door=0, EventIndex=1710962226986 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:24 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:24, DeviceDate=#20.03.2024 21:22:19, EventCode=90, Door=0, EventIndex=1710962539119 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:24 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:24, DeviceDate=#20.03.2024 21:30:48, EventCode=49, Door=0, EventIndex=1710963048740 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:24 --- NOTICE: event-87 Дверь открыта картой 3530279 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:24 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:24#, DeviceDate=#20.03.2024 21:34:13#, EventCode=50, Door=0, EventIndex=1710963253586, Card="3530279" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:24 --- NOTICE: event-87 Дверь открыта картой 9793475 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:24 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:24#, DeviceDate=#20.03.2024 21:36:36#, EventCode=50, Door=0, EventIndex=1710963396747, Card="9793475" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:24 --- NOTICE: event-87 Дверь открыта картой 8105360 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:24 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:24#, DeviceDate=#20.03.2024 21:39:54#, EventCode=50, Door=0, EventIndex=1710963594785, Card="8105360" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:24 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710964475369
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:24 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1710964475623
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:24 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:24, DeviceDate=#20.03.2024 21:59:37, EventCode=49, Door=0, EventIndex=1710964777011 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:24 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:24, DeviceDate=#20.03.2024 22:12:35, EventCode=49, Door=0, EventIndex=1710965555231 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:24 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:24, DeviceDate=#20.03.2024 22:33:11, EventCode=49, Door=0, EventIndex=1710966791992 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:24 --- NOTICE: event-87 Дверь открыта картой 3530279 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:24 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:24#, DeviceDate=#20.03.2024 22:36:18#, EventCode=50, Door=0, EventIndex=1710966978525, Card="3530279" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:24 --- NOTICE: event-87 Дверь открыта картой 11965509 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:24 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:24#, DeviceDate=#20.03.2024 22:43:51#, EventCode=50, Door=0, EventIndex=1710967431631, Card="11965509" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:24 --- NOTICE: event-87 Дверь открыта картой 2539109 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:24 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:24#, DeviceDate=#20.03.2024 22:47:26#, EventCode=50, Door=0, EventIndex=1710967646459, Card="2539109" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:24 --- NOTICE: event-87 Дверь открыта картой 5406413 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:24 --- NOTICE: +Device="2.4 Вест, Readdate =#25.03.2024 17:55:24#, DeviceDate=#20.03.2024 22:49:40#, EventCode=50, Door=0, EventIndex=1710967780934, Card="5406413" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:24 --- NOTICE: 17:55:24 ev- 137 работа с контроллером 10.200.32.3 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:25 --- NOTICE: ev=34 Начало работы с панелью 10.200.15.4, id_dev= 149, device="1.5 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:25 --- NOTICE: #43 Панель 10.200.15.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:25 --- NOTICE: event-43 провожу авторизацию панели id_dev=149, id_ctrl=39,  baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:25 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:25 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:55:25 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:55:25 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:25 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:25 --- NOTICE: 17:55:25 ev- 137 работа с контроллером 10.200.15.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:25 --- NOTICE: ev=34 Начало работы с панелью 10.200.12.4, id_dev= 182, device="1.2 ЗВЖ 1". in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:25 --- NOTICE: #43 Панель 10.200.12.4 на связи 1, av08fb, 1.9.0 20230519, 3.21.4, 2.9.0 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:25 --- NOTICE: event-43 провожу авторизацию панели id_dev=182, id_ctrl=50,  baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:25 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:25 --- NOTICE: #677 Установка времени невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-25 17:55:25 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-25 17:55:25 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:25 --- NOTICE: 121 Новых событий нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:25 --- NOTICE: 17:55:25 ev- 137 работа с контроллером 10.200.12.4 завершена.

 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-25 17:55:25 --- NOTICE: event-142 stop minion basgetevent.php. Выборка событий завершена. Время выполнения timeExecute=10.809041023254 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250