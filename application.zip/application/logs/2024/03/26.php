<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2024-03-26 00:00:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:00:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:00:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:00:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:00:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:00:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:00:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:00:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:00:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:00:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:00:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:00:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:00:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:00:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:00:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:00:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:00:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:00:11 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 19:58:35 (1711389515135) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:00:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:00:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:00:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:00:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:00:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:00:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:00:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:00:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:00:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:00:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:00:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:00:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:05:09 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:05:10 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:05:10 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:05:10 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:05:10 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:05:10 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:05:10 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:05:10 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:05:10 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:05:10 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:05:11 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:05:11 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:05:11 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:05:11 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:05:11 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:05:14 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:05:14 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:05:15 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:05:20 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:05:20 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:05:21 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:05:21 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:05:21 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 19:58:35 (1711389515135) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:05:21 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:05:21 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:05:21 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:05:21 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:05:21 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:05:21 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:05:21 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:05:21 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:05:21 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:05:21 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:05:22 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:05:22 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:10:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:10:04 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:10:04 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:10:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:10:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:10:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:10:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:10:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:10:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:10:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:10:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:10:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:10:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:10:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:10:12 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 19:58:35 (1711389515135) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:10:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:10:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:10:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:10:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:10:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:10:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:10:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:10:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:10:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:10:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:10:13 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:10:13 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:15:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:15:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:15:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:15:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:15:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:15:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:15:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:15:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:15:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:15:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:15:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:15:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:15:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:15:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:15:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:15:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:15:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:15:12 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 19:58:35 (1711389515135) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:15:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:15:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:15:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:15:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:15:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:15:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:15:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:15:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:15:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:15:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:15:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:15:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:20:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:20:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:20:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:20:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:20:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:20:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:20:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:20:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:20:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:20:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:20:15 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:20:15 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:20:15 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:20:20 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:20:20 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:20:20 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:20:20 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:20:20 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 19:58:35 (1711389515135) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:20:20 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:20:20 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:20:20 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:20:20 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:20:20 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:20:20 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:20:20 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:20:21 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:20:21 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:20:21 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:20:21 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:20:21 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:25:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:25:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:25:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:25:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:25:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:25:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:25:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:25:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:25:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:25:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:25:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:25:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:25:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:25:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:25:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:25:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:25:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:25:11 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 19:58:35 (1711389515135) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:25:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:25:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:25:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:25:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:25:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:25:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:25:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:25:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:25:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:25:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:25:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:25:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:30:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:30:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:30:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:30:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:30:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:30:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:30:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:30:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:30:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:30:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:30:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:30:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:30:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:30:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:30:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:30:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:30:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:30:11 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 19:58:35 (1711389515135) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:30:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:30:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:30:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:30:11 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:30:11 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:30:11 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:30:11 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:30:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:30:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:30:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:30:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:30:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:35:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:35:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:35:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:35:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:35:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:35:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:35:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:35:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:35:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:35:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:35:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:35:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:35:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:35:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:35:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:35:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:35:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:35:11 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 19:58:35 (1711389515135) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:35:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:35:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:35:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:35:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:35:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:35:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:35:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:35:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:35:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:35:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:35:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:35:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:40:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:40:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:40:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:40:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:40:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:40:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:40:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:40:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:40:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:40:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:40:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:40:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:40:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:40:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:40:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:40:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:40:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:40:11 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 19:58:35 (1711389515135) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:40:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:40:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:40:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:40:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:40:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:40:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:40:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:40:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:40:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:40:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:40:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:40:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:45:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:45:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:45:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:45:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:45:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:45:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:45:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:45:16 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:45:16 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:45:16 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:45:21 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:45:21 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:45:21 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:45:21 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:45:21 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 19:58:35 (1711389515135) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:45:21 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:45:21 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:45:21 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:45:22 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:45:22 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:45:22 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:45:22 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:45:22 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:45:22 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:45:22 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:45:22 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:45:22 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:50:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:50:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:50:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:50:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:50:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:50:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:50:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:50:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:50:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:50:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:50:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:50:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:50:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:50:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:50:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:50:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:50:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:50:11 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 19:58:35 (1711389515135) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:50:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:50:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:50:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:50:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:50:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:50:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:50:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:50:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:50:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:50:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:50:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:50:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:55:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:55:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:55:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:55:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:55:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:55:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:55:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:55:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:55:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:55:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:55:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:55:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:55:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:55:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:55:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:55:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:55:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:55:11 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 19:58:35 (1711389515135) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:55:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:55:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:55:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:55:11 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:55:11 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:55:11 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:55:11 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:55:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:55:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 00:55:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 00:55:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 00:55:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:00:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:00:04 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:00:04 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:00:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:00:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:00:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:00:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:00:14 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:00:14 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:00:14 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:00:19 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:00:19 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:00:20 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:00:20 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:00:20 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 19:58:35 (1711389515135) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:00:20 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:00:20 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:00:20 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:00:20 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:00:20 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:00:20 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:00:20 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:00:20 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:00:21 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:00:21 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:00:21 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:00:21 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:05:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:05:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:05:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:05:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:05:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:05:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:05:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:05:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:05:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:05:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:05:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:05:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:05:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:05:12 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:05:12 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:05:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:05:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:05:12 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 19:58:35 (1711389515135) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:05:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:05:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:05:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:05:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:05:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:05:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:05:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:05:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:05:13 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:05:13 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:05:13 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:05:13 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:10:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:10:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:10:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:10:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:10:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:10:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:10:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:10:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:10:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:10:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:10:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:10:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:10:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:10:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:10:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:10:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:10:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:10:11 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 19:58:35 (1711389515135) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:10:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:10:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:10:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:10:11 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:10:11 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:10:11 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:10:11 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:10:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:10:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:10:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:10:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:10:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:15:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:15:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:15:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:15:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:15:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:15:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:15:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:15:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:15:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:15:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:15:14 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:15:14 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:15:14 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:15:19 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:15:19 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:15:19 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:15:19 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:15:19 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 19:58:35 (1711389515135) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:15:20 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:15:20 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:15:20 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:15:20 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:15:20 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:15:20 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:15:20 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:15:20 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:15:20 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:15:20 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:15:20 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:15:20 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:20:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:20:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:20:11 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 19:58:35 (1711389515135) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:20:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 1 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:11 --- NOTICE: event-87 Дверь открыта картой 3530279 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:11 --- NOTICE: +Device="2.4 Вест, Readdate =#26.03.2024 01:20:11#, DeviceDate=#26.03.2024 01:16:08#, EventCode=50, Door=0, EventIndex=1711408568192, Card="3530279" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:11 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:20:11 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:20:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:20:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:20:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:20:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:25:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:25:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:25:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:25:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:25:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:25:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:25:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:25:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:25:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:25:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:25:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:25:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:25:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:25:12 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:25:12 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:25:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:25:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:25:12 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:25:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:25:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:25:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:25:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:25:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:25:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:25:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:25:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:25:13 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:25:13 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:25:13 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:25:13 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:30:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:30:08 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:30:08 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:30:08 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:30:08 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:30:08 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:30:09 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:30:09 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:30:09 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:30:09 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:30:10 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:30:10 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:30:10 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:30:10 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:30:10 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:30:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:30:12 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:30:12 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:30:17 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:30:17 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:30:17 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:30:17 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:30:17 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:30:17 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:30:17 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:30:18 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:30:18 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:30:18 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:30:18 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:30:18 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:30:18 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:30:18 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:30:18 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:30:18 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:30:18 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:35:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:35:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:35:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:35:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:35:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:35:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:35:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:35:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:35:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:35:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:35:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:35:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:35:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:35:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:35:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:35:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:35:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:35:12 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:35:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:35:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:35:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:35:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:35:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:35:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:35:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:35:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:35:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:35:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:35:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:35:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:40:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:40:09 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:40:09 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:40:09 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:40:09 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:40:09 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:40:09 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:40:09 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:40:09 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:40:09 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:40:09 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:40:09 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:40:09 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:40:09 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:40:09 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:40:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:40:11 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:40:11 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:40:16 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:40:16 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:40:17 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:40:17 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:40:17 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:40:17 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:40:17 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:40:17 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:40:17 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:40:17 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:40:17 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:40:17 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:40:17 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:40:17 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:40:17 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:40:18 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:40:18 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:45:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:45:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:45:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:45:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:45:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:45:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:45:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:45:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:45:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:45:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:45:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:45:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:45:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:45:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:45:11 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:45:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:45:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:45:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:45:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:45:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:45:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:45:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:45:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:45:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:45:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:45:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:45:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:50:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:50:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:50:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:50:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:50:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:50:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:50:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:50:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:50:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:50:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:50:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:50:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:50:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:50:12 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:50:12 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:50:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:50:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:50:12 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:50:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:50:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:50:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:50:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:50:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:50:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:50:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:50:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:50:13 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:50:13 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:50:13 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:50:13 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:55:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:55:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:55:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:55:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:55:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:55:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:55:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:55:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:55:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:55:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:55:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:55:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:55:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:55:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:55:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:55:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:55:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:55:12 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:55:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:55:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:55:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:55:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:55:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:55:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:55:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:55:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:55:13 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 01:55:13 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 01:55:13 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 01:55:13 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:00:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:00:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:00:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:00:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:00:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:00:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:00:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:00:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:00:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:00:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:00:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:00:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:00:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:00:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:00:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:00:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:00:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:00:11 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:00:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:00:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:00:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:00:11 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:00:11 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:00:11 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:00:11 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:00:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:00:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:00:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:00:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:00:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:05:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:05:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:05:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:05:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:05:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:05:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:05:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:05:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:05:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:05:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:05:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:05:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:05:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:05:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:05:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:05:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:05:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:05:12 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:05:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:05:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:05:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:05:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:05:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:05:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:05:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:05:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:05:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:05:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:05:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:05:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:10:04 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:10:04 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:10:04 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:10:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:10:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:10:05 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:10:05 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:10:05 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:10:05 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:10:05 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:10:07 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:10:07 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:10:07 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:10:12 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:10:12 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:10:17 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:10:17 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:10:17 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:10:17 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:10:17 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:10:17 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:10:17 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:10:17 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:10:17 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:10:17 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:10:18 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:10:18 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:10:18 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:10:18 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:10:18 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:15:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:15:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:15:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:15:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:15:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:15:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:15:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:15:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:15:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:15:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:15:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:15:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:15:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:15:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:15:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:15:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:15:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:15:11 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:15:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:15:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:15:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:15:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:15:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:15:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:15:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:15:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:15:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:15:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:15:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:15:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:20:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:20:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:20:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:20:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:20:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:20:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:20:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:20:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:20:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:20:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:20:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:20:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:20:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:20:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:20:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:20:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:20:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:20:12 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:20:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:20:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:20:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:20:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:20:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:20:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:20:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:20:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:20:13 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:20:13 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:20:13 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:20:13 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:25:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:25:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:25:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:25:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:25:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:25:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:25:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:25:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:25:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:25:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:25:15 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:25:15 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:25:15 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:25:20 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:25:20 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:25:20 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:25:20 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:25:20 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:25:21 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:25:21 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:25:21 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:25:21 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:25:21 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:25:21 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:25:21 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:25:21 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:25:21 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:25:21 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:25:21 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:25:21 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:30:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:30:04 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:30:04 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:30:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:30:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:30:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:30:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:30:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:30:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:30:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:30:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:30:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:30:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:30:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:30:12 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:30:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:30:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:30:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:30:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:30:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:30:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:30:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:30:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:30:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:30:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:30:13 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:30:13 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:35:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:35:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:35:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:35:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:35:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:35:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:35:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:35:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:35:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:35:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:35:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:35:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:35:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:35:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:35:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:35:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:35:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:35:11 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:35:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:35:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:35:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:35:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:35:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:35:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:35:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:35:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:35:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:35:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:35:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:35:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:40:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:40:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:40:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:40:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:40:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:40:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:40:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:40:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:40:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:40:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:40:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:40:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:40:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:40:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:40:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:40:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:40:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:40:11 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:40:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:40:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:40:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:40:11 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:40:11 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:40:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:40:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:40:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:40:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:40:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:40:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:40:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:45:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:45:10 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:45:10 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:45:10 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:45:10 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:45:10 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:45:10 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:45:10 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:45:10 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:45:10 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:45:10 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:45:10 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:45:10 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:45:10 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:45:10 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:45:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:45:13 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:45:13 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:45:18 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:45:18 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:45:18 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:45:18 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:45:18 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:45:18 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:45:18 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:45:18 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:45:19 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:45:19 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:45:19 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:45:19 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:45:19 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:45:19 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:45:19 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:45:19 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:45:19 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:50:18 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:50:19 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:50:19 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:50:19 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:50:19 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:50:19 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:50:20 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:50:20 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:50:20 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:50:20 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:50:20 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:50:20 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:50:20 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:50:20 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:50:20 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:50:25 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:50:25 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:50:25 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:50:30 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:50:30 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:50:30 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:50:30 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:50:30 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:50:30 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:50:30 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:50:31 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:50:31 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:50:31 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:50:31 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:50:31 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:50:31 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:50:31 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:50:31 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:50:31 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:50:31 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:55:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:55:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:55:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:55:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:55:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:55:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:55:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:55:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:55:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:55:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:55:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:55:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:55:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:55:12 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:55:12 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:55:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:55:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:55:12 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:55:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:55:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:55:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:55:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:55:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:55:13 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:55:13 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:55:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:55:13 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 02:55:13 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 02:55:13 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 02:55:13 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:00:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:00:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:00:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:00:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:00:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:00:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:00:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:00:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:00:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:00:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:00:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:00:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:00:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:00:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:00:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:00:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:00:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:00:11 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:00:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:00:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:00:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:00:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:00:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:00:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:00:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:00:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:00:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:00:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:00:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:00:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:05:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:05:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:05:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:05:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:05:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:05:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:05:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:05:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:05:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:05:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:05:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:05:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:05:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:05:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:05:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:05:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:05:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:05:12 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:05:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:05:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:05:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:05:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:05:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:05:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:05:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:05:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:05:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:05:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:05:13 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:05:13 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:10:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:10:04 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:10:04 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:10:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:10:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:10:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:10:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:10:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:10:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:10:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:10:12 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:10:12 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:10:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:10:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:10:12 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:10:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:10:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:10:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:10:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:10:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:10:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:10:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:10:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:10:13 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:10:13 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:10:13 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:10:13 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:15:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:15:04 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:15:04 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:15:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:15:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:15:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:15:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:15:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:15:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:15:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:15:12 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:15:12 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:15:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:15:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:15:12 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:15:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:15:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:15:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:15:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:15:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:15:13 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:15:13 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:15:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:15:13 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:15:13 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:15:13 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:15:13 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:20:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:20:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:20:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:20:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:20:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:20:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:20:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:20:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:20:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:20:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:20:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:20:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:20:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:20:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:20:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:20:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:20:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:20:11 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:20:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:20:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:20:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:20:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:20:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:20:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:20:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:20:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:20:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:20:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:20:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:20:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:25:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:25:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:25:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:25:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:25:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:25:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:25:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:25:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:25:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:25:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:25:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:25:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:25:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:25:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:25:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:25:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:25:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:25:11 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:25:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:25:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:25:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:25:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:25:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:25:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:25:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:25:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:25:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:25:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:25:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:25:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:30:09 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:30:10 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:30:10 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:30:10 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:30:10 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:30:10 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:30:10 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:30:10 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:30:10 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:30:10 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:30:10 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:30:10 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:30:10 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:30:10 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:30:10 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:30:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:30:12 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:30:12 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:30:17 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:30:17 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:30:18 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:30:18 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:30:18 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:30:18 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:30:18 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:30:18 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:30:18 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:30:18 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:30:18 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:30:18 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:30:18 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:30:18 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:30:18 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:30:19 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:30:19 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:35:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:35:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:35:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:35:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:35:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:35:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:35:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:35:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:35:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:35:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:35:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:35:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:35:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:35:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:35:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:35:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:35:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:35:12 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:35:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:35:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:35:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:35:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:35:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:35:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:35:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:35:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:35:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:35:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:35:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:35:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:40:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:40:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:40:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:40:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:40:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:40:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:40:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:40:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:40:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:40:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:40:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:40:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:40:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:40:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:40:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:40:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:40:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:40:12 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:40:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:40:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:40:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:40:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:40:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:40:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:40:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:40:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:40:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:40:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:40:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:40:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:45:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:45:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:45:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:45:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:45:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:45:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:45:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:45:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:45:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:45:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:45:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:45:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:45:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:45:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:45:11 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:45:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:45:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:45:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:45:11 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:45:11 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:45:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:45:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:45:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:45:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:45:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:45:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:45:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:50:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:50:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:50:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:50:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:50:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:50:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:50:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:50:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:50:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:50:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:50:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:50:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:50:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:50:10 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:50:10 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:50:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:50:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:50:11 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:50:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:50:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:50:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:50:11 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:50:11 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:50:11 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:50:11 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:50:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:50:11 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:50:11 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:50:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:50:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:55:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:55:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:55:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:55:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:55:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:55:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:55:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:55:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:55:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:55:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:55:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:55:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:55:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:55:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:55:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:55:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:55:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:55:12 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:55:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:55:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:55:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:55:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:55:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:55:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:55:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:55:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:55:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 03:55:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 03:55:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 03:55:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:00:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:00:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:00:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:00:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:00:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:00:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:00:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:00:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:00:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:00:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:00:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:00:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:00:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:00:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:00:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:00:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:00:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:00:11 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:00:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:00:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:00:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:00:11 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:00:11 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:00:11 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:00:11 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:00:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:00:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:00:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:00:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:00:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:05:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:05:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:05:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:05:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:05:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:05:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:05:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:05:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:05:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:05:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:05:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:05:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:05:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:05:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:05:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:05:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:05:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:05:12 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:05:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:05:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:05:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:05:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:05:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:05:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:05:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:05:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:05:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:05:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:05:13 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:05:13 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:10:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:10:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:10:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:10:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:10:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:10:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:10:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:10:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:10:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:10:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:10:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:10:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:10:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:10:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:10:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:10:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:10:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:10:12 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:10:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:10:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:10:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:10:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:10:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:10:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:10:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:10:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:10:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:10:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:10:13 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:10:13 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:15:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:15:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:15:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:15:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:15:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:15:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:15:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:15:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:15:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:15:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:15:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:15:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:15:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:15:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:15:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:15:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:15:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:15:11 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:15:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:15:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:15:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:15:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:15:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:15:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:15:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:15:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:15:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:15:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:15:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:15:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:20:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:20:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:20:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:20:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:20:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:20:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:20:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:20:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:20:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:20:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:20:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:20:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:20:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:20:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:20:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:20:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:20:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:20:11 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:20:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:20:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:20:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:20:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:20:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:20:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:20:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:20:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:20:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:20:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:20:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:20:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:25:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:25:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:25:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:25:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:25:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:25:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:25:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:25:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:25:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:25:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:25:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:25:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:25:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:25:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:25:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:25:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:25:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:25:11 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:25:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:25:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:25:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:25:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:25:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:25:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:25:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:25:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:25:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:25:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:25:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:25:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:30:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:30:12 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:30:12 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:30:12 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:30:12 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:30:12 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:30:13 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:30:13 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:30:13 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:30:13 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:30:13 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:30:13 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:30:13 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:30:13 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:30:13 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:30:15 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:30:15 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:30:15 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:30:20 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:30:20 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:30:20 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:30:20 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:30:20 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:30:20 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:30:20 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:30:21 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:30:21 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:30:21 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:30:21 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:30:21 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:30:21 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:30:21 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:30:21 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:30:21 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:30:21 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:35:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:35:04 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:35:04 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:35:05 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:35:05 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:35:05 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:35:05 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:35:05 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:35:05 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:35:05 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:35:05 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:35:05 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:35:07 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:35:07 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:35:07 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:35:12 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:35:12 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:35:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:35:13 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:35:13 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:35:13 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:35:13 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:35:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:35:13 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:35:13 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:35:13 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:35:13 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:35:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:35:14 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:35:14 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:35:14 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:35:14 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:40:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:40:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:40:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:40:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:40:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:40:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:40:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:40:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:40:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:40:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:40:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:40:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:40:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:40:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:40:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:40:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:40:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:40:11 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:40:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:40:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:40:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:40:11 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:40:11 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:40:11 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:40:11 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:40:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:40:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:40:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:40:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:40:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:45:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:45:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:45:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:45:03 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:45:03 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:45:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:45:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:45:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:45:13 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:45:13 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:45:18 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:45:18 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:45:18 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:45:19 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:45:19 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:45:19 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:45:19 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:45:19 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:45:19 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:45:19 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:45:19 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:45:19 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:45:19 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:45:19 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:45:19 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:45:19 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:45:19 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:50:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:50:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:50:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:50:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:50:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:50:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:50:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:50:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:50:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:50:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:50:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:50:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:50:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:50:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:50:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:50:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:50:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:50:11 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:50:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:50:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:50:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:50:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:50:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:50:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:50:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:50:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:50:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:50:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:50:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:50:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:55:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:55:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:55:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:55:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:55:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:55:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:55:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:55:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:55:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:55:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:55:14 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:55:14 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:55:14 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:55:19 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:55:19 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:55:20 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:55:20 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:55:20 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:55:20 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:55:20 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:55:20 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:55:20 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:55:20 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:55:20 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:55:20 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:55:21 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:55:21 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 04:55:21 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 04:55:21 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 04:55:21 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:00:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:00:08 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:00:08 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:00:08 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:00:08 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:00:08 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:00:08 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:00:08 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:00:08 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:00:08 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:00:08 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:00:08 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:00:08 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:00:08 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:00:08 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:00:10 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:00:10 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:00:10 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:00:16 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:00:16 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:00:16 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:00:16 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:00:16 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:00:16 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:00:16 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:00:16 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:00:16 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:00:16 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:00:16 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:00:16 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:00:17 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:00:17 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:00:17 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:00:17 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:00:17 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:05:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:05:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:05:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:05:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:05:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:05:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:05:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:05:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:05:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:05:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:05:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:05:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:05:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:05:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:05:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:05:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:05:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:05:11 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:05:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:05:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:05:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:05:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:05:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:05:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:05:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:05:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:05:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:05:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:05:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:05:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:10:07 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:10:08 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:10:08 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:10:08 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:10:08 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:10:08 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:10:08 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:10:08 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:10:08 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:10:08 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:10:08 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:10:08 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:10:08 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:10:08 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:10:08 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:10:10 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:10:10 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:10:10 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:10:16 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:10:16 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:10:16 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:10:17 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:10:17 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:10:17 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:10:17 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:10:17 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:10:17 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:10:17 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:10:17 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:10:17 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:10:17 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:10:17 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:10:17 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:10:17 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:10:17 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:15:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:15:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:15:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:15:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:15:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:15:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:15:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:15:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:15:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:15:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:15:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:15:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:15:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:15:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:15:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:15:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:15:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:15:11 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:15:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:15:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:15:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:15:11 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:15:11 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:15:11 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:15:11 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:15:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:15:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:15:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:15:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:15:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:20:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:20:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:20:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:20:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:20:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:20:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:20:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:20:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:20:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:20:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:20:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:20:15 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:20:15 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:20:20 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:20:20 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:20:20 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:20:20 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:20:20 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:20:20 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:20:20 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:20:21 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:20:21 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:20:21 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:20:21 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:20:21 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:20:21 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:20:21 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:20:21 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:20:21 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:20:21 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:25:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:25:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:25:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:25:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:25:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:25:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:25:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:25:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:25:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:25:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:25:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:25:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:25:06 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:25:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:25:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:25:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:25:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:25:11 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:25:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:25:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:25:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:25:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:25:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:25:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:25:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:25:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:25:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:25:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:25:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:25:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:30:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:30:07 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:30:07 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:30:07 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:30:07 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:30:07 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:30:07 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:30:07 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:30:07 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:30:07 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:30:08 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:30:08 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:30:08 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:30:08 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:30:08 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:30:09 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:30:10 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:30:10 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:30:15 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:30:15 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:30:15 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:30:16 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:30:16 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:30:16 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:30:16 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:30:16 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:30:16 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:30:16 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:30:16 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:30:16 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:30:16 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:30:16 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:30:16 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:30:16 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:30:16 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:35:05 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:35:06 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:35:06 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:35:06 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:35:06 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:35:06 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:35:06 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:35:06 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:35:06 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:35:06 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:35:06 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:35:06 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:35:06 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:35:06 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:35:06 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:35:09 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:35:09 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:35:09 --- NOTICE: #545 Получение событий начиная с метки 25.03.2024 22:10:18 (1711397418825) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:35:14 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 1 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:35:14 --- NOTICE: +Device="2.1 Вест, Readdate =#26.03.2024 05:35:14, DeviceDate=#26.03.2024 05:32:42, EventCode=49, Door=0, EventIndex=1711423962769 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:35:14 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:35:14 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:35:14 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:35:14 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:35:14 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:35:14 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:35:14 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:35:14 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:35:14 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:35:14 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:35:15 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:35:15 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:35:15 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:35:15 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:35:15 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:40:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:40:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:40:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:40:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:40:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:40:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:40:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:40:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:40:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:40:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:40:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:40:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:40:06 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 05:32:42 (1711423962769) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:40:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:40:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:40:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:40:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:40:11 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:40:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:40:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:40:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:40:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:40:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:40:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:40:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:40:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:40:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:40:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:40:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:40:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:45:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:45:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:45:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:45:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:45:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:45:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:45:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:45:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:45:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:45:06 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 05:32:42 (1711423962769) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:45:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:45:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:45:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:45:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:45:12 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:45:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:45:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:45:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:45:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:45:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:45:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:45:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:45:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:45:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:45:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:45:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:45:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:50:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:50:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:50:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:50:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:50:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:50:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:50:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:50:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:50:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:50:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:50:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:50:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:50:06 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 05:32:42 (1711423962769) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:50:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:50:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:50:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:50:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:50:11 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:50:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:50:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:50:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:50:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:50:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:50:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:50:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:50:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:50:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:50:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:50:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:50:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:55:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:55:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:55:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:55:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:55:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:55:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:55:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:55:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:55:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:55:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:55:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:55:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:55:06 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 05:32:42 (1711423962769) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:55:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:55:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:55:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:55:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:55:11 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:55:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:55:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:55:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:55:11 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:55:11 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:55:11 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:55:11 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:55:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:55:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 05:55:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 05:55:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 05:55:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:00:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:00:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:00:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:00:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:00:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:00:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:00:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:00:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:00:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:00:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:00:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:00:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:00:06 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 05:32:42 (1711423962769) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:00:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:00:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:00:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:00:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:00:12 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:00:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:00:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:00:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:00:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:00:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:00:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:00:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:00:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:00:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:00:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:00:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:00:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:05:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:05:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:05:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:05:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:05:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:05:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:05:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:05:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:05:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:05:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:05:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:05:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:05:06 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 05:32:42 (1711423962769) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:05:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:05:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:05:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:05:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:05:11 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:05:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:05:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:05:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:05:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:05:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:05:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:05:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:05:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:05:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:05:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:05:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:05:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:10:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:10:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:10:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:10:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:10:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:10:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:10:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:10:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:10:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:10:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:10:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:10:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:10:06 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 05:32:42 (1711423962769) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:10:12 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:10:12 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:10:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:10:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:10:12 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:10:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:10:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:10:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:10:13 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:10:13 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:10:13 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:10:13 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:10:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:10:13 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:10:13 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:10:13 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:10:13 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:15:14 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:15:14 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:15:14 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:15:14 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:15:14 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:15:14 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:15:15 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:15:15 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:15:15 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:15:15 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:15:15 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:15:15 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:15:15 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:15:15 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:15:15 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:15:30 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:15:30 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:15:30 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 05:32:42 (1711423962769) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:15:35 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:15:35 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:15:35 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:15:35 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:15:35 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:15:36 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:15:36 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:15:36 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:15:36 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:15:36 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:15:36 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:15:36 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:15:36 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:15:36 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:15:36 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:15:36 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:15:36 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:20:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:20:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:20:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:20:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:20:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:20:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:20:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:20:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:20:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:20:14 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:20:14 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:20:14 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 05:32:42 (1711423962769) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:20:19 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:20:19 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:20:20 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:20:20 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:20:20 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:20:20 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:20:20 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:20:20 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:20:20 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:20:20 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:20:20 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:20:20 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:20:20 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:20:20 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:20:20 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:20:21 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:20:21 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:25:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:25:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:25:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:25:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:25:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:25:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:25:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:25:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:25:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:25:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:25:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:25:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:25:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:25:06 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 05:32:42 (1711423962769) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:25:12 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:25:12 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:25:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:25:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:25:12 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:25:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:25:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:25:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:25:13 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:25:13 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:25:13 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:25:13 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:25:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:25:13 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:25:13 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:25:13 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:25:13 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:30:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:30:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:30:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:30:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:30:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:30:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:30:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:30:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:30:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:30:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:30:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:30:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:30:06 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 05:32:42 (1711423962769) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:30:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:30:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:30:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:30:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:30:12 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:30:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:30:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:30:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:30:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:30:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:30:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:30:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:30:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:30:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:30:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:30:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:30:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:35:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:35:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:35:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:35:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:35:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:35:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:35:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:35:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:35:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:35:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:35:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:35:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:35:06 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 05:32:42 (1711423962769) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:35:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:35:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:35:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:35:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:35:11 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:35:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:35:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:35:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:35:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:35:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:35:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:35:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:35:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:35:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:35:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:35:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:35:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:40:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:40:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:40:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:40:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:40:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:40:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:40:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:40:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:40:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:40:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:40:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:40:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:40:06 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 05:32:42 (1711423962769) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:40:12 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:40:12 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:40:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:40:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:40:12 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:40:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:40:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:40:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:40:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:40:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:40:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:40:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:40:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:40:13 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:40:13 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:40:13 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:40:13 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:45:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:45:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:45:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:45:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:45:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:45:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:45:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:45:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:45:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:45:06 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 05:32:42 (1711423962769) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:45:12 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:45:12 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:45:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:45:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:45:12 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:45:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:45:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:45:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:45:13 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:45:13 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:45:13 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:45:13 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:45:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:45:13 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:45:13 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:45:13 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:45:13 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:50:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:50:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:50:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:50:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:50:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:50:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:50:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:50:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:50:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:50:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:50:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:50:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:50:06 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 05:32:42 (1711423962769) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:50:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:50:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:50:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:50:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:50:11 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:50:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:50:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:50:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:50:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:50:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:50:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:50:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:50:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:50:13 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:50:13 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:50:13 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:50:13 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:55:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:55:06 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:55:06 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:55:06 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:55:06 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:55:06 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:55:06 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:55:06 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:55:06 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:55:06 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:55:06 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:55:06 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:55:06 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:55:06 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:55:06 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:55:08 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:55:08 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:55:08 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 05:32:42 (1711423962769) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:55:13 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:55:13 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:55:14 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:55:14 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:55:14 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:55:14 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:55:14 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:55:14 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:55:14 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:55:14 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:55:14 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:55:14 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:55:14 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:55:14 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 06:55:14 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 06:55:15 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 06:55:15 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:00:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:00:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:00:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:00:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:00:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:00:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:00:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:00:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:00:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:00:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:00:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:00:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:00:06 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 05:32:42 (1711423962769) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 07:00:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:00:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:00:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:00:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:00:11 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 07:00:11 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:00:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:00:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:00:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:00:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 07:00:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:00:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:00:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:00:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:00:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 07:00:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:00:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:05:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:05:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:05:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:05:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:05:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:05:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:05:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:05:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:05:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:05:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:05:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:05:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:05:06 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 05:32:42 (1711423962769) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 07:05:12 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:05:12 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:05:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:05:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:05:12 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 07:05:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:05:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:05:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:05:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:05:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 07:05:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:05:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:05:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:05:13 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:05:13 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 07:05:13 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:05:13 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:10:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:10:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:10:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:10:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:10:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:10:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:10:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:10:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:10:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:10:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:10:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:10:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:10:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:10:06 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 05:32:42 (1711423962769) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 07:10:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:10:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:10:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:10:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:10:12 --- NOTICE: #545 Получение событий начиная с метки 26.03.2024 01:16:08 (1711408568192) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 07:10:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:10:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:10:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:10:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:10:12 --- NOTICE: #545 Получение событий начиная с метки 04.03.2024 18:08:00 (1709568480008) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 07:10:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:10:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:10:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:10:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:10:12 --- NOTICE: #545 Получение событий начиная с метки 24.03.2024 17:50:12 (1711295412709) in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:61
2024-03-26 07:10:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:10:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:15:11 --- NOTICE: event-56 Получил от 10.200.20.2 массив из 4 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:11 --- NOTICE: +Device="2.1 Вест, Readdate =#26.03.2024 07:15:11, DeviceDate=#26.03.2024 07:12:28, EventCode=49, Door=0, EventIndex=1711429948195 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:11 --- NOTICE: +Device="2.1 Вест, Readdate =#26.03.2024 07:15:11, DeviceDate=#26.03.2024 07:13:11, EventCode=49, Door=0, EventIndex=1711429991995 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:11 --- NOTICE: +Device="2.1 Вест, Readdate =#26.03.2024 07:15:11, DeviceDate=#26.03.2024 07:13:36, EventCode=49, Door=0, EventIndex=1711430016664 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:11 --- NOTICE: +Device="2.1 Вест, Readdate =#26.03.2024 07:15:11, DeviceDate=#26.03.2024 07:14:45, EventCode=49, Door=0, EventIndex=1711430085795 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:15:12 --- NOTICE: event-56 Получил от 10.200.32.3 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:15:12 --- NOTICE: event-56 Получил от 10.200.15.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:15:12 --- NOTICE: event-56 Получил от 10.200.12.4 массив из 0 событий in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:15:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:20:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:20:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:20:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:20:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:20:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:20:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:20:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:20:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:20:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:20:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:20:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:20:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:20:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:20:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:20:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:20:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:20:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:20:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:20:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:20:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:20:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:20:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:25:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:25:07 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:25:07 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:25:07 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:25:07 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:25:07 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:25:08 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:25:08 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:25:08 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:25:08 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:25:08 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:25:08 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:25:08 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:25:08 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:25:08 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:25:10 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:25:10 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:25:16 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:25:16 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:25:16 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:25:16 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:25:17 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:25:17 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:25:17 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:25:17 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:25:17 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:25:17 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:30:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:30:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:30:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:30:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:30:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:30:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:30:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:30:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:30:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:30:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:30:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:30:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:30:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:30:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:30:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:30:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:30:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:30:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:30:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:30:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:30:13 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:30:13 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:35:07 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:35:12 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:35:12 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:35:12 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:35:12 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:35:12 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:35:13 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:35:13 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:35:13 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:35:13 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:35:13 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:35:13 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:35:13 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:35:13 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:35:13 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:35:15 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:35:15 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:35:21 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:35:21 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:35:21 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:35:22 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:35:22 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:35:22 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:35:22 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:35:22 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:35:22 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:35:23 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1711431291888
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(29)</span> "access_denied_by_unknown_card"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:35:23 --- NOTICE: event-87 Дверь открыта картой 852074 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:35:23 --- NOTICE: +Device="1.2 ЗВЖ 1, Readdate =#26.03.2024 07:35:23#, DeviceDate=#26.03.2024 07:34:54#, EventCode=50, Door=0, EventIndex=1711431294439, Card="852074" in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:40:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:40:05 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:40:05 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:40:05 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:40:05 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:40:05 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:40:06 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:40:06 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:40:06 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:40:06 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:40:06 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:40:06 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:40:06 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:40:06 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:40:06 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:40:08 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:40:08 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:40:13 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:40:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:40:13 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:40:13 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:40:14 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:40:14 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:40:14 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:40:14 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:40:14 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:40:14 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:45:02 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:45:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:45:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:45:03 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:45:03 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:45:03 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:45:03 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:45:05 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:45:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:45:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:45:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:45:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:45:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:45:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:45:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:45:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:45:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:45:13 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:45:13 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:50:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:50:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:50:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:50:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:50:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:50:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:50:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:50:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:50:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:50:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:50:07 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:50:07 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:50:12 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:50:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:50:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:50:12 --- NOTICE: +Device="2.4 Вест, Readdate =#26.03.2024 07:50:12, DeviceDate=#26.03.2024 07:48:28, EventCode=49, Door=0, EventIndex=1711432108294 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:50:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:50:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:50:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:50:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:50:13 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:50:13 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:55:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:55:04 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:55:04 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:55:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:55:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:55:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:55:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:55:18 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:55:18 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:55:23 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:55:23 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:55:24 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:55:24 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:55:24 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:55:24 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:55:24 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:55:24 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 07:55:24 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 07:55:24 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:00:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:00:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:00:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:00:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:00:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:00:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:00:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:00:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:00:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:00:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:00:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:00:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:00:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:00:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:00:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:00:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:00:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:00:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:00:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:00:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:00:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:00:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:05:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:05:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:05:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:05:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:05:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:05:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:05:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:05:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:05:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:05:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:05:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:05:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:05:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:05:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:05:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:05:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:05:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:05:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:05:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:05:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:05:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:05:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:05:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:10:08 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:10:09 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:10:09 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:10:09 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:10:09 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:10:09 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:10:09 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:10:09 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:10:09 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:10:09 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:10:09 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:10:09 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:10:09 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:10:09 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:10:09 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:10:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:10:12 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:10:17 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:10:18 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:10:18 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:10:18 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:10:18 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:10:18 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:10:18 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:10:18 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:10:18 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:10:19 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:15:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:15:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:15:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:15:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:15:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:15:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:15:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:15:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:15:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:15:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:15:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:15:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:15:12 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:15:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:15:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:15:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:15:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:15:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:15:13 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:15:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:15:13 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:15:13 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:04 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:04 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:20:11 --- NOTICE: +Device="2.1 Вест, Readdate =#26.03.2024 08:20:11, DeviceDate=#26.03.2024 08:15:52, EventCode=49, Door=0, EventIndex=1711433752352 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:11 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1711433774567
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:11 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1711433775621
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:11 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1711433776605
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:11 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1711433787337
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:11 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1711433789291
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:11 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1711433792297
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:11 --- NOTICE: event-94 Неизвестное событие <pre class="debug"><small>object</small> <span>Model_basEvent(5)</span> <code>{
    <small>public</small> timestamp => <small>float</small> 1711433796547
    <small>public</small> category => <small>string</small><span>(1)</span> "-"
    <small>public</small> info => <small>string</small><span>(3)</span> "bas"
    <small>public</small> name => <small>string</small><span>(27)</span> "access_granted_by_call_host"
    <small>public</small> number => <small>NULL</small>
}</code></pre> in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:11 --- NOTICE: +Device="2.1 Вест, Readdate =#26.03.2024 08:20:11, DeviceDate=#26.03.2024 08:16:48, EventCode=49, Door=0, EventIndex=1711433808546 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:11 --- NOTICE: +Device="2.1 Вест, Readdate =#26.03.2024 08:20:11, DeviceDate=#26.03.2024 08:17:06, EventCode=49, Door=0, EventIndex=1711433826116 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:11 --- NOTICE: +Device="2.1 Вест, Readdate =#26.03.2024 08:20:11, DeviceDate=#26.03.2024 08:18:18, EventCode=49, Door=0, EventIndex=1711433898992 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:11 --- NOTICE: +Device="2.1 Вест, Readdate =#26.03.2024 08:20:11, DeviceDate=#26.03.2024 08:19:05, EventCode=49, Door=0, EventIndex=1711433945110 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:20:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:20:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:20:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:20:13 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:25:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:25:05 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:25:05 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:25:05 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:25:05 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:25:05 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:25:05 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:25:05 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:25:05 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:25:05 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:25:06 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:25:06 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:25:06 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:25:06 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:25:06 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:25:08 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:25:08 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:25:13 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:25:14 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:25:14 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:25:14 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:25:14 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:25:14 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:25:14 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:25:15 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:25:15 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:25:15 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:30:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:30:04 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:30:04 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:30:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:30:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:30:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:30:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:30:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:30:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:30:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:30:12 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:30:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:30:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:30:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:30:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:30:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:30:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:30:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:30:13 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:30:13 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:35:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:35:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:35:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:35:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:35:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:35:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:35:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:35:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:35:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:35:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:35:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:35:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:35:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:35:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:35:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:35:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:35:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:35:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:35:11 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:35:11 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:35:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:35:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:35:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:40:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:40:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:40:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:40:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:40:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:40:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:40:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:40:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:40:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:40:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:40:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:40:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:40:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:40:12 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:40:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:40:12 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:40:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:40:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:40:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:40:13 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:40:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:40:13 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:40:13 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:45:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:45:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:45:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:45:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:45:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:45:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:45:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:45:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:45:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:45:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:45:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:45:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:45:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:45:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:45:11 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:45:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:45:11 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:45:11 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:45:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:45:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:45:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:50:02 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:50:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:50:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:50:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:50:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:50:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:50:03 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:50:03 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:50:03 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:50:03 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:50:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:50:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:50:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:50:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:50:06 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:50:11 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:50:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:50:11 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:50:12 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:50:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:50:12 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:50:12 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:50:12 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:50:12 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:50:12 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:55:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:55:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:55:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:55:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:55:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:55:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:55:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:55:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:55:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:55:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:55:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:55:16 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:55:16 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:55:22 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:55:23 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:55:23 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:55:23 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:55:23 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:55:23 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:55:23 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:55:23 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 08:55:24 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 08:55:24 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:00:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:00:03 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:00:03 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:00:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:00:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:00:03 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:00:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:00:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:00:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:00:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:00:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:00:07 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:00:07 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 09:00:10 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:00:10 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:00:10 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 09:00:10 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:00:10 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:00:10 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 09:00:11 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:00:11 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:00:11 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 09:00:11 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:05:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:05:11 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:05:11 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:05:11 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:05:11 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:05:11 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:05:11 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:05:11 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:05:11 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:05:11 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:05:11 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:05:11 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:05:11 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:05:11 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:05:11 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:05:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:05:13 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 09:05:19 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:05:19 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:05:19 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 09:05:19 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:05:19 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:05:19 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 09:05:19 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:05:20 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:05:20 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 09:05:20 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:10:04 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:10:05 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:10:05 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:10:05 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:10:05 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:10:05 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:10:05 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:10:05 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:10:05 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:10:05 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:10:05 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:10:05 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:10:05 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:10:05 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:10:05 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:10:07 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:10:07 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 09:10:12 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:10:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:10:13 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 09:10:13 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:10:13 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:10:13 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 09:10:13 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:10:14 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:10:14 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 09:10:14 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:15:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:15:04 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:15:04 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:15:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:15:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:15:04 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:15:04 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:15:04 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:15:06 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.20.2,  name='2.1 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:15:16 --- NOTICE: #677 Установка времени 10.200.20.2 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 09:15:21 --- NOTICE: 121 Новых событий 10.200.20.2 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:15:21 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.32.3,  name='2.4 Вест' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:15:21 --- NOTICE: #677 Установка времени 10.200.32.3 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 09:15:21 --- NOTICE: 121 Новых событий 10.200.32.3 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:15:21 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.15.4,  name='1.5 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:15:21 --- NOTICE: #677 Установка времени 10.200.15.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 09:15:21 --- NOTICE: 121 Новых событий 10.200.15.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:15:22 --- NOTICE: event-260 авторизация в устройстве baseurl=10.200.12.4,  name='1.2 ЗВЖ 1' выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:15:22 --- NOTICE: #677 Установка времени 10.200.12.4 невозможна. Для установки времени необходимо выключить NTP в настройках устройства. in C:\xampp\htdocs\bas\application\classes\Task\basgetevent.php:60
2024-03-26 09:15:22 --- NOTICE: 121 Новых событий 10.200.12.4 нет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:20:03 --- NOTICE: rw-14 start basrwrfid.php in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:20:04 --- NOTICE: 260 авторизация в устройстве 101 IP 10.200.20.2 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:20:04 --- NOTICE: 49 список карт для 10.200.20.2. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 10809903" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.20.2. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:20:04 --- NOTICE: 260 авторизация в устройстве 110 IP 10.200.32.3 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:20:04 --- NOTICE: 49 список карт для 10.200.32.3. Количество карт для записи 2 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:20:04 --- NOTICE: 75 Ошибка валидации для 10.200.32.3. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:20:05 --- NOTICE: 260 авторизация в устройстве 182 IP 10.200.12.4 выполнена успешно. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:20:05 --- NOTICE: 49 список карт для 10.200.12.4. Количество карт для записи 3 in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:20:05 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:20:05 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 09:20:05 --- NOTICE: 75 Ошибка валидации для 10.200.12.4. key=" 3147288" Номер карты must be a digit Номер карты в панель записываться не будет. in C:\xampp\htdocs\bas\modules\minion\classes\Kohana\Minion\Task.php:250
2024-03-26 11:23:46 --- DEBUG: #28 could not find driver in C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php:18
2024-03-26 11:23:46 --- CRITICAL: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\Dashboard.php [ 35 ] in C:\xampp\htdocs\bas\application\views\Dashboard.php:35
2024-03-26 11:23:46 --- DEBUG: #0 C:\xampp\htdocs\bas\application\views\Dashboard.php(35): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\\xampp\\htdocs...', 35, Array)
#1 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\bas\application\views\template.php(81): Kohana_View->__toString()
#5 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\bas\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#11 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\bas\application\views\Dashboard.php:35
2024-03-26 11:28:32 --- DEBUG: #47 Данные из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(13)</span> "192.168.89.12"
        "id_dev" => <small>string</small><span>(2)</span> "88"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> удалеы успешно перед последующей вставкой. SQL=delete from bas_param bp
				where bp.id_dev=88
				and bp.param='IP' in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-26 11:28:32 --- DEBUG: #t6-time 0.030735015869141 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-26 11:28:32 --- DEBUG: #56 вставка данных  из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(13)</span> "192.168.89.12"
        "id_dev" => <small>string</small><span>(2)</span> "88"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> прошла с ошибкой. SQL=INSERT INTO BAS_PARAM (ID_DEV, PARAM, INTVALUE) VALUES (88, 'IP',  '-1062708980'); SQLSTATE[IM001]: Driver does not support this function: driver does not support lastInsertId() in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-26 11:28:32 --- DEBUG: #99-time 0.037718057632446 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-26 11:28:40 --- DEBUG: #47 Данные из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(13)</span> "192.168.89.22"
        "id_dev" => <small>string</small><span>(2)</span> "88"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> удалеы успешно перед последующей вставкой. SQL=delete from bas_param bp
				where bp.id_dev=88
				and bp.param='IP' in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-26 11:28:40 --- DEBUG: #t6-time 0.022156000137329 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-26 11:28:40 --- DEBUG: #56 вставка данных  из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(13)</span> "192.168.89.22"
        "id_dev" => <small>string</small><span>(2)</span> "88"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> прошла с ошибкой. SQL=INSERT INTO BAS_PARAM (ID_DEV, PARAM, INTVALUE) VALUES (88, 'IP',  '-1062708970'); SQLSTATE[IM001]: Driver does not support this function: driver does not support lastInsertId() in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-26 11:28:40 --- DEBUG: #99-time 0.027532815933228 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-26 11:28:44 --- DEBUG: #47 Данные из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(13)</span> "192.168.89.12"
        "id_dev" => <small>string</small><span>(2)</span> "88"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> удалеы успешно перед последующей вставкой. SQL=delete from bas_param bp
				where bp.id_dev=88
				and bp.param='IP' in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-26 11:28:44 --- DEBUG: #t6-time 0.012104034423828 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-26 11:28:44 --- DEBUG: #56 вставка данных  из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(13)</span> "192.168.89.12"
        "id_dev" => <small>string</small><span>(2)</span> "88"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> прошла с ошибкой. SQL=INSERT INTO BAS_PARAM (ID_DEV, PARAM, INTVALUE) VALUES (88, 'IP',  '-1062708980'); SQLSTATE[IM001]: Driver does not support this function: driver does not support lastInsertId() in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-26 11:28:44 --- DEBUG: #99-time 0.01512598991394 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-26 11:59:30 --- CRITICAL: PDOException [ IM001 ]: SQLSTATE[IM001]: Driver does not support this function: driver does not support lastInsertId() ~ MODPATH\database\classes\Kohana\Database\PDO.php [ 198 ] in C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\PDO.php:198
2024-03-26 11:59:30 --- DEBUG: #0 C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\PDO.php(198): PDO->lastInsertId()
#1 C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_PDO->query(2, 'INSERT INTO bas...', false, Array)
#2 C:\xampp\htdocs\bas\application\classes\Model\bas.php(588): Kohana_Database_Query->execute(Object(Database_PDO))
#3 C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php(346): Model_Bas->updateData('test1', 'test2', '')
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_update()
#5 [internal function]: Kohana_Controller->execute()
#6 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#7 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#10 {main} in C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\PDO.php:198
2024-03-26 12:06:54 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH\classes\Model\bas.php [ 591 ] in C:\xampp\htdocs\bas\application\classes\Model\bas.php:591
2024-03-26 12:06:54 --- DEBUG: #0 C:\xampp\htdocs\bas\application\classes\Model\bas.php(591): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 591, Array)
#1 C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php(346): Model_Bas->updateData('test1', 'test3', '')
#2 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_update()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#5 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#8 {main} in C:\xampp\htdocs\bas\application\classes\Model\bas.php:591
2024-03-26 12:07:48 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH\classes\Model\bas.php [ 591 ] in C:\xampp\htdocs\bas\application\classes\Model\bas.php:591
2024-03-26 12:07:48 --- DEBUG: #0 C:\xampp\htdocs\bas\application\classes\Model\bas.php(591): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 591, Array)
#1 C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php(346): Model_Bas->updateData('test1', 'test3', '')
#2 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_update()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#5 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#8 {main} in C:\xampp\htdocs\bas\application\classes\Model\bas.php:591
2024-03-26 12:07:51 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH\classes\Model\bas.php [ 591 ] in C:\xampp\htdocs\bas\application\classes\Model\bas.php:591
2024-03-26 12:07:51 --- DEBUG: #0 C:\xampp\htdocs\bas\application\classes\Model\bas.php(591): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 591, Array)
#1 C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php(346): Model_Bas->updateData('test1', 'test3', '')
#2 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_update()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#5 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#8 {main} in C:\xampp\htdocs\bas\application\classes\Model\bas.php:591
2024-03-26 12:07:57 --- CRITICAL: PDOException [ IM001 ]: SQLSTATE[IM001]: Driver does not support this function: driver does not support lastInsertId() ~ MODPATH\database\classes\Kohana\Database\PDO.php [ 198 ] in C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\PDO.php:198
2024-03-26 12:07:57 --- DEBUG: #0 C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\PDO.php(198): PDO->lastInsertId()
#1 C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_PDO->query(2, 'INSERT INTO bas...', false, Array)
#2 C:\xampp\htdocs\bas\application\classes\Model\bas.php(588): Kohana_Database_Query->execute(Object(Database_PDO))
#3 C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php(346): Model_Bas->updateData('test1', 'test3', '')
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_update()
#5 [internal function]: Kohana_Controller->execute()
#6 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#7 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#10 {main} in C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\PDO.php:198
2024-03-26 12:09:56 --- CRITICAL: Database_Exception [ HY000 ]: SQLSTATE[HY000]: General error: 0 [Gemini InterBase ODBC Driver][INTERBASE]Dynamic SQL Error. SQL error code = -104. Token unknown - line 1, char 85. ).  (SQLPrepare[0] at ext\pdo_odbc\odbc_driver.c:206) [ INSERT INTO bas_param (ID_DEV, PARAM, INTVALUE, STRVALUE) VALUES (0, 'login', NULL, ) RETURNING id ] ~ MODPATH\database\classes\Kohana\Database\PDO.php [ 157 ] in C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\Query.php:251
2024-03-26 12:09:56 --- DEBUG: #0 C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_PDO->query(2, 'INSERT INTO bas...', false, Array)
#1 C:\xampp\htdocs\bas\application\classes\Model\bas.php(584): Kohana_Database_Query->execute(Object(Database_PDO))
#2 C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php(346): Model_Bas->updateData('test1', 'test3', '')
#3 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_update()
#4 [internal function]: Kohana_Controller->execute()
#5 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#6 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#9 {main} in C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\Query.php:251
2024-03-26 12:12:05 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '$insert_result_login' (T_VARIABLE) ~ APPPATH\classes\Model\bas.php [ 584 ] in file:line
2024-03-26 12:12:05 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-26 12:12:07 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '$insert_result_login' (T_VARIABLE) ~ APPPATH\classes\Model\bas.php [ 584 ] in file:line
2024-03-26 12:12:07 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-26 12:12:25 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '$insert_result_login' (T_VARIABLE) ~ APPPATH\classes\Model\bas.php [ 584 ] in file:line
2024-03-26 12:12:25 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-26 12:12:49 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '$insert_result_login' (T_VARIABLE) ~ APPPATH\classes\Model\bas.php [ 584 ] in file:line
2024-03-26 12:12:49 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-26 12:12:51 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '$insert_result_login' (T_VARIABLE) ~ APPPATH\classes\Model\bas.php [ 584 ] in file:line
2024-03-26 12:12:51 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-26 12:15:13 --- CRITICAL: Database_Exception [ HY000 ]: SQLSTATE[HY000]: General error: 0 [Gemini InterBase ODBC Driver][INTERBASE]Dynamic SQL Error. SQL error code = -104. Token unknown - line 1, char 95. RETURNING.  (SQLPrepare[0] at ext\pdo_odbc\odbc_driver.c:206) [ INSERT INTO bas_param (ID_DEV, PARAM, INTVALUE, STRVALUE) VALUES (0, 'login', NULL, ' test1') RETURNING id ] ~ MODPATH\database\classes\Kohana\Database\PDO.php [ 157 ] in C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\Query.php:251
2024-03-26 12:15:13 --- DEBUG: #0 C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_PDO->query(2, 'INSERT INTO bas...', false, Array)
#1 C:\xampp\htdocs\bas\application\classes\Model\bas.php(582): Kohana_Database_Query->execute(Object(Database_PDO))
#2 C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php(346): Model_Bas->updateData('test1', 'test2', '')
#3 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_update()
#4 [internal function]: Kohana_Controller->execute()
#5 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#6 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#9 {main} in C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\Query.php:251
2024-03-26 12:17:19 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected 'echo' (T_ECHO), expecting ';' or '{' ~ APPPATH\classes\Model\bas.php [ 525 ] in file:line
2024-03-26 12:17:19 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-26 12:23:31 --- CRITICAL: Database_Exception [ HY000 ]: SQLSTATE[HY000]: General error: 0 [Gemini InterBase ODBC Driver][INTERBASE]Dynamic SQL Error. SQL error code = -104. Token unknown - line 1, char 96. RETURNING.  (SQLPrepare[0] at ext\pdo_odbc\odbc_driver.c:206) [ INSERT INTO bas_param (ID_DEV, PARAM, INTVALUE, STRVALUE) VALUES (88, 'login', NULL, ' test2') RETURNING id ] ~ MODPATH\database\classes\Kohana\Database\PDO.php [ 157 ] in C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\Query.php:251
2024-03-26 12:23:31 --- DEBUG: #0 C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_PDO->query(2, 'INSERT INTO bas...', false, Array)
#1 C:\xampp\htdocs\bas\application\classes\Model\bas.php(583): Kohana_Database_Query->execute(Object(Database_PDO))
#2 C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php(346): Model_Bas->updateData('test2', 'test1', '88')
#3 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_update()
#4 [internal function]: Kohana_Controller->execute()
#5 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#6 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#7 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#8 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#9 {main} in C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\Query.php:251
2024-03-26 12:25:37 --- CRITICAL: PDOException [ IM001 ]: SQLSTATE[IM001]: Driver does not support this function: driver does not support lastInsertId() ~ MODPATH\database\classes\Kohana\Database\PDO.php [ 198 ] in C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\PDO.php:198
2024-03-26 12:25:37 --- DEBUG: #0 C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\PDO.php(198): PDO->lastInsertId()
#1 C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\Query.php(251): Kohana_Database_PDO->query(2, 'INSERT INTO bas...', false, Array)
#2 C:\xampp\htdocs\bas\application\classes\Model\bas.php(583): Kohana_Database_Query->execute(Object(Database_PDO))
#3 C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php(346): Model_Bas->updateData('test2', 'test1', '88')
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_update()
#5 [internal function]: Kohana_Controller->execute()
#6 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#7 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#9 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#10 {main} in C:\xampp\htdocs\bas\modules\database\classes\Kohana\Database\PDO.php:198
2024-03-26 12:27:55 --- CRITICAL: ErrorException [ 1 ]: Class 'Database_Pdo' not found ~ MODPATH\database\classes\Kohana\Database.php [ 78 ] in file:line
2024-03-26 12:27:55 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-26 12:29:42 --- CRITICAL: ErrorException [ 1 ]: Call to a member function current() on array ~ APPPATH\classes\Model\bas.php [ 584 ] in file:line
2024-03-26 12:29:42 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-26 12:39:58 --- CRITICAL: ErrorException [ 8 ]: Use of undefined constant validation - assumed 'validation' ~ APPPATH\classes\Controller\Dashboard.php [ 352 ] in C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php:352
2024-03-26 12:39:58 --- DEBUG: #0 C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php(352): Kohana_Core::error_handler(8, 'Use of undefine...', 'C:\\xampp\\htdocs...', 352, Array)
#1 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_update()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#7 {main} in C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php:352
2024-03-26 12:51:12 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: login ~ APPPATH\classes\Controller\Dashboard.php [ 355 ] in C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php:355
2024-03-26 12:51:12 --- DEBUG: #0 C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php(355): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 355, Array)
#1 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_update()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#7 {main} in C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php:355
2024-03-26 13:08:17 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '{', expecting '(' ~ APPPATH\classes\Model\bas.php [ 594 ] in file:line
2024-03-26 13:08:17 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-26 13:08:33 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ')', expecting identifier (T_STRING) or namespace (T_NAMESPACE) or \\ (T_NS_SEPARATOR) ~ APPPATH\classes\Model\bas.php [ 594 ] in file:line
2024-03-26 13:08:33 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-26 13:08:47 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '{', expecting '(' ~ APPPATH\classes\Model\bas.php [ 594 ] in file:line
2024-03-26 13:08:47 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-26 13:08:57 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '{', expecting '(' ~ APPPATH\classes\Model\bas.php [ 594 ] in file:line
2024-03-26 13:08:57 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-26 13:09:14 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '{', expecting '(' ~ APPPATH\classes\Model\bas.php [ 594 ] in file:line
2024-03-26 13:09:14 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-26 13:09:18 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ')', expecting identifier (T_STRING) or namespace (T_NAMESPACE) or \\ (T_NS_SEPARATOR) ~ APPPATH\classes\Model\bas.php [ 594 ] in file:line
2024-03-26 13:09:18 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-26 13:11:57 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '$data' (T_VARIABLE) ~ APPPATH\classes\Controller\Dashboard.php [ 372 ] in file:line
2024-03-26 13:11:57 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-26 13:13:08 --- CRITICAL: ErrorException [ 8 ]: Array to string conversion ~ APPPATH\classes\Controller\Dashboard.php [ 372 ] in C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php:372
2024-03-26 13:13:08 --- DEBUG: #0 C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php(372): Kohana_Core::error_handler(8, 'Array to string...', 'C:\\xampp\\htdocs...', 372, Array)
#1 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_update()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#7 {main} in C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php:372
2024-03-26 13:13:55 --- CRITICAL: ErrorException [ 8 ]: Array to string conversion ~ APPPATH\classes\Controller\Dashboard.php [ 372 ] in C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php:372
2024-03-26 13:13:55 --- DEBUG: #0 C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php(372): Kohana_Core::error_handler(8, 'Array to string...', 'C:\\xampp\\htdocs...', 372, Array)
#1 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_update()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#7 {main} in C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php:372
2024-03-26 13:21:31 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: session ~ APPPATH\classes\Controller\Dashboard.php [ 371 ] in C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php:371
2024-03-26 13:21:31 --- DEBUG: #0 C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php(371): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 371, Array)
#1 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_update()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#7 {main} in C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php:371
2024-03-26 13:22:14 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected 'if' (T_IF) ~ APPPATH\views\Dashboard.php [ 7 ] in file:line
2024-03-26 13:22:14 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-26 13:22:35 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: session ~ APPPATH\views\Dashboard.php [ 6 ] in C:\xampp\htdocs\bas\application\views\Dashboard.php:6
2024-03-26 13:22:35 --- DEBUG: #0 C:\xampp\htdocs\bas\application\views\Dashboard.php(6): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 6, Array)
#1 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\bas\application\views\template.php(81): Kohana_View->__toString()
#5 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\bas\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#11 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\bas\application\views\Dashboard.php:6
2024-03-26 13:34:23 --- CRITICAL: ErrorException [ 8 ]: Array to string conversion ~ APPPATH\views\Dashboard.php [ 10 ] in C:\xampp\htdocs\bas\application\views\Dashboard.php:10
2024-03-26 13:34:23 --- DEBUG: #0 C:\xampp\htdocs\bas\application\views\Dashboard.php(10): Kohana_Core::error_handler(8, 'Array to string...', 'C:\\xampp\\htdocs...', 10, Array)
#1 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\bas\application\views\template.php(81): Kohana_View->__toString()
#5 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\bas\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#11 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\bas\application\views\Dashboard.php:10
2024-03-26 13:35:50 --- CRITICAL: ErrorException [ 8 ]: Array to string conversion ~ APPPATH\views\Dashboard.php [ 10 ] in C:\xampp\htdocs\bas\application\views\Dashboard.php:10
2024-03-26 13:35:50 --- DEBUG: #0 C:\xampp\htdocs\bas\application\views\Dashboard.php(10): Kohana_Core::error_handler(8, 'Array to string...', 'C:\\xampp\\htdocs...', 10, Array)
#1 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\bas\application\views\template.php(81): Kohana_View->__toString()
#5 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\bas\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#11 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\bas\application\views\Dashboard.php:10
2024-03-26 13:38:19 --- CRITICAL: ErrorException [ 8 ]: Array to string conversion ~ APPPATH\views\Dashboard.php [ 10 ] in C:\xampp\htdocs\bas\application\views\Dashboard.php:10
2024-03-26 13:38:19 --- DEBUG: #0 C:\xampp\htdocs\bas\application\views\Dashboard.php(10): Kohana_Core::error_handler(8, 'Array to string...', 'C:\\xampp\\htdocs...', 10, Array)
#1 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\bas\application\views\template.php(81): Kohana_View->__toString()
#5 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\bas\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#11 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\bas\application\views\Dashboard.php:10
2024-03-26 13:38:56 --- CRITICAL: ErrorException [ 2 ]: implode(): Invalid arguments passed ~ APPPATH\views\Dashboard.php [ 9 ] in file:line
2024-03-26 13:38:56 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'implode(): Inva...', 'C:\\xampp\\htdocs...', 9, Array)
#1 C:\xampp\htdocs\bas\application\views\Dashboard.php(9): implode(',', NULL)
#2 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#3 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#4 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(236): Kohana_View->render()
#5 C:\xampp\htdocs\bas\application\views\template.php(81): Kohana_View->__toString()
#6 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#7 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#9 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#10 [internal function]: Kohana_Controller->execute()
#11 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#12 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#13 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#14 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#15 {main} in file:line
2024-03-26 13:43:24 --- CRITICAL: ErrorException [ 2 ]: implode(): Invalid arguments passed ~ APPPATH\views\Dashboard.php [ 8 ] in file:line
2024-03-26 13:43:24 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'implode(): Inva...', 'C:\\xampp\\htdocs...', 8, Array)
#1 C:\xampp\htdocs\bas\application\views\Dashboard.php(8): implode(',', NULL)
#2 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#3 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#4 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(236): Kohana_View->render()
#5 C:\xampp\htdocs\bas\application\views\template.php(81): Kohana_View->__toString()
#6 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#7 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#9 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#10 [internal function]: Kohana_Controller->execute()
#11 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#12 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#13 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#14 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#15 {main} in file:line
2024-03-26 13:46:07 --- CRITICAL: ErrorException [ 2 ]: implode(): Invalid arguments passed ~ APPPATH\views\Dashboard.php [ 13 ] in file:line
2024-03-26 13:46:07 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'implode(): Inva...', 'C:\\xampp\\htdocs...', 13, Array)
#1 C:\xampp\htdocs\bas\application\views\Dashboard.php(13): implode(',', '\xD0\x98\xD0\xB7\xD0\xBC\xD0\xB5\xD0\xBD\xD0\xB5\xD0\xBD\xD0...')
#2 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#3 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#4 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(236): Kohana_View->render()
#5 C:\xampp\htdocs\bas\application\views\template.php(81): Kohana_View->__toString()
#6 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#7 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#9 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#10 [internal function]: Kohana_Controller->execute()
#11 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#12 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#13 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#14 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#15 {main} in file:line
2024-03-26 13:49:13 --- CRITICAL: ErrorException [ 2 ]: implode(): Invalid arguments passed ~ APPPATH\views\Dashboard.php [ 16 ] in file:line
2024-03-26 13:49:13 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'implode(): Inva...', 'C:\\xampp\\htdocs...', 16, Array)
#1 C:\xampp\htdocs\bas\application\views\Dashboard.php(16): implode(',', '')
#2 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#3 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#4 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(236): Kohana_View->render()
#5 C:\xampp\htdocs\bas\application\views\template.php(81): Kohana_View->__toString()
#6 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#7 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#9 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#10 [internal function]: Kohana_Controller->execute()
#11 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#12 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#13 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#14 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#15 {main} in file:line
2024-03-26 13:50:46 --- CRITICAL: ErrorException [ 2 ]: implode(): Invalid arguments passed ~ APPPATH\views\Dashboard.php [ 16 ] in file:line
2024-03-26 13:50:46 --- DEBUG: #0 [internal function]: Kohana_Core::error_handler(2, 'implode(): Inva...', 'C:\\xampp\\htdocs...', 16, Array)
#1 C:\xampp\htdocs\bas\application\views\Dashboard.php(16): implode(',', 'array(0)')
#2 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#3 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#4 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(236): Kohana_View->render()
#5 C:\xampp\htdocs\bas\application\views\template.php(81): Kohana_View->__toString()
#6 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#7 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#9 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#10 [internal function]: Kohana_Controller->execute()
#11 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#12 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#13 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#14 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#15 {main} in file:line
2024-03-26 13:56:49 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected 'alert' (T_STRING), expecting ',' or ';' ~ APPPATH\views\Dashboard.php [ 15 ] in file:line
2024-03-26 13:56:49 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-26 13:57:08 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '$sd' (T_VARIABLE), expecting ',' or ';' ~ APPPATH\views\Dashboard.php [ 15 ] in file:line
2024-03-26 13:57:08 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-26 13:57:24 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '$sd' (T_VARIABLE), expecting ',' or ';' ~ APPPATH\views\Dashboard.php [ 15 ] in file:line
2024-03-26 13:57:24 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-26 14:13:02 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: id_dev ~ APPPATH\views\Dashboard.php [ 21 ] in C:\xampp\htdocs\bas\application\views\Dashboard.php:21
2024-03-26 14:13:02 --- DEBUG: #0 C:\xampp\htdocs\bas\application\views\Dashboard.php(21): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 21, Array)
#1 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\bas\application\views\template.php(81): Kohana_View->__toString()
#5 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\bas\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#11 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\bas\application\views\Dashboard.php:21
2024-03-26 14:14:34 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '?' ~ APPPATH\views\Dashboard.php [ 11 ] in file:line
2024-03-26 14:14:34 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-26 14:34:06 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id_dev ~ APPPATH\views\Dashboard.php [ 11 ] in C:\xampp\htdocs\bas\application\views\Dashboard.php:11
2024-03-26 14:34:06 --- DEBUG: #0 C:\xampp\htdocs\bas\application\views\Dashboard.php(11): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\\xampp\\htdocs...', 11, Array)
#1 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\bas\application\views\template.php(81): Kohana_View->__toString()
#5 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\bas\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#11 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\bas\application\views\Dashboard.php:11
2024-03-26 14:34:15 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id_dev ~ APPPATH\views\Dashboard.php [ 11 ] in C:\xampp\htdocs\bas\application\views\Dashboard.php:11
2024-03-26 14:34:15 --- DEBUG: #0 C:\xampp\htdocs\bas\application\views\Dashboard.php(11): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\\xampp\\htdocs...', 11, Array)
#1 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\bas\application\views\template.php(81): Kohana_View->__toString()
#5 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\bas\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#11 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\bas\application\views\Dashboard.php:11
2024-03-26 14:36:00 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id_dev ~ APPPATH\views\Dashboard.php [ 11 ] in C:\xampp\htdocs\bas\application\views\Dashboard.php:11
2024-03-26 14:36:00 --- DEBUG: #0 C:\xampp\htdocs\bas\application\views\Dashboard.php(11): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\\xampp\\htdocs...', 11, Array)
#1 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\bas\application\views\template.php(81): Kohana_View->__toString()
#5 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\bas\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#11 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\bas\application\views\Dashboard.php:11
2024-03-26 14:37:20 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: id_dev ~ APPPATH\views\Dashboard.php [ 21 ] in C:\xampp\htdocs\bas\application\views\Dashboard.php:21
2024-03-26 14:37:20 --- DEBUG: #0 C:\xampp\htdocs\bas\application\views\Dashboard.php(21): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 21, Array)
#1 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\bas\application\views\template.php(81): Kohana_View->__toString()
#5 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\bas\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#11 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\bas\application\views\Dashboard.php:21