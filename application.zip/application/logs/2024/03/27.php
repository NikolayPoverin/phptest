<?php defined('SYSPATH') OR die('No direct script access.'); ?>

2024-03-27 02:59:17 --- DEBUG: #28 SQLSTATE[08001] SQLConnect: 0 [Gemini InterBase ODBC Driver]Client unable to establish connection. Client library cannot be loaded in C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php:18
2024-03-27 02:59:17 --- CRITICAL: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\Dashboard.php [ 68 ] in C:\xampp\htdocs\bas\application\views\Dashboard.php:68
2024-03-27 02:59:17 --- DEBUG: #0 C:\xampp\htdocs\bas\application\views\Dashboard.php(68): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\\xampp\\htdocs...', 68, Array)
#1 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\bas\application\views\template.php(81): Kohana_View->__toString()
#5 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\bas\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#11 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\bas\application\views\Dashboard.php:68
2024-03-27 03:09:58 --- DEBUG: #28 SQLSTATE[08001] SQLConnect: 0 [Gemini InterBase ODBC Driver]Client unable to establish connection. Client library cannot be loaded in C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php:18
2024-03-27 03:09:58 --- CRITICAL: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\Dashboard.php [ 68 ] in C:\xampp\htdocs\bas\application\views\Dashboard.php:68
2024-03-27 03:09:58 --- DEBUG: #0 C:\xampp\htdocs\bas\application\views\Dashboard.php(68): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\\xampp\\htdocs...', 68, Array)
#1 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\bas\application\views\template.php(81): Kohana_View->__toString()
#5 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\bas\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#11 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\bas\application\views\Dashboard.php:68
2024-03-27 03:10:50 --- DEBUG: #28 could not find driver in C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php:18
2024-03-27 03:10:51 --- CRITICAL: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\Dashboard.php [ 68 ] in C:\xampp\htdocs\bas\application\views\Dashboard.php:68
2024-03-27 03:10:51 --- DEBUG: #0 C:\xampp\htdocs\bas\application\views\Dashboard.php(68): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\\xampp\\htdocs...', 68, Array)
#1 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\bas\application\views\template.php(81): Kohana_View->__toString()
#5 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\bas\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#11 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\bas\application\views\Dashboard.php:68
2024-03-27 03:11:07 --- DEBUG: #28 could not find driver in C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php:18
2024-03-27 03:11:07 --- CRITICAL: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\Dashboard.php [ 57 ] in C:\xampp\htdocs\bas\application\views\Dashboard.php:57
2024-03-27 03:11:07 --- DEBUG: #0 C:\xampp\htdocs\bas\application\views\Dashboard.php(57): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\\xampp\\htdocs...', 57, Array)
#1 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\bas\application\views\template.php(81): Kohana_View->__toString()
#5 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\bas\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#11 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\bas\application\views\Dashboard.php:57
2024-03-27 12:27:42 --- DEBUG: #28 could not find driver in C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php:18
2024-03-27 12:27:42 --- CRITICAL: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\Dashboard.php [ 68 ] in C:\xampp\htdocs\bas\application\views\Dashboard.php:68
2024-03-27 12:27:42 --- DEBUG: #0 C:\xampp\htdocs\bas\application\views\Dashboard.php(68): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\\xampp\\htdocs...', 68, Array)
#1 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\bas\application\views\template.php(81): Kohana_View->__toString()
#5 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\bas\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#11 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\bas\application\views\Dashboard.php:68
2024-03-27 12:28:36 --- DEBUG: #28 could not find driver in C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php:18
2024-03-27 12:28:36 --- CRITICAL: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\Dashboard.php [ 68 ] in C:\xampp\htdocs\bas\application\views\Dashboard.php:68
2024-03-27 12:28:36 --- DEBUG: #0 C:\xampp\htdocs\bas\application\views\Dashboard.php(68): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\\xampp\\htdocs...', 68, Array)
#1 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\bas\application\views\template.php(81): Kohana_View->__toString()
#5 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\bas\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#11 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\bas\application\views\Dashboard.php:68
2024-03-27 12:29:16 --- DEBUG: #28 could not find driver in C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php:18
2024-03-27 12:29:16 --- CRITICAL: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\Dashboard.php [ 68 ] in C:\xampp\htdocs\bas\application\views\Dashboard.php:68
2024-03-27 12:29:16 --- DEBUG: #0 C:\xampp\htdocs\bas\application\views\Dashboard.php(68): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\\xampp\\htdocs...', 68, Array)
#1 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\bas\application\views\template.php(81): Kohana_View->__toString()
#5 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\bas\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#11 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\bas\application\views\Dashboard.php:68
2024-03-27 12:38:57 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected 'login' (T_STRING), expecting ',' or ';' ~ APPPATH\views\Dashboard.php [ 87 ] in file:line
2024-03-27 12:38:57 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-27 12:39:11 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected 'login' (T_STRING), expecting ',' or ';' ~ APPPATH\views\Dashboard.php [ 87 ] in file:line
2024-03-27 12:39:11 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-27 12:41:46 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected 'windows' (T_STRING), expecting ',' or ';' ~ APPPATH\views\Dashboard.php [ 85 ] in file:line
2024-03-27 12:41:46 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-27 12:50:23 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected 'ID_SERVER' (T_STRING) ~ APPPATH\classes\Model\bas.php [ 85 ] in file:line
2024-03-27 12:50:23 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-27 13:19:57 --- DEBUG: #28 Undefined index: id_dev in C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php:18
2024-03-27 13:19:57 --- CRITICAL: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\Dashboard.php [ 68 ] in C:\xampp\htdocs\bas\application\views\Dashboard.php:68
2024-03-27 13:19:57 --- DEBUG: #0 C:\xampp\htdocs\bas\application\views\Dashboard.php(68): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\\xampp\\htdocs...', 68, Array)
#1 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\bas\application\views\template.php(81): Kohana_View->__toString()
#5 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\bas\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#11 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\bas\application\views\Dashboard.php:68
2024-03-27 13:20:09 --- DEBUG: #28 Undefined index: id_dev in C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php:18
2024-03-27 13:20:09 --- CRITICAL: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH\views\Dashboard.php [ 68 ] in C:\xampp\htdocs\bas\application\views\Dashboard.php:68
2024-03-27 13:20:09 --- DEBUG: #0 C:\xampp\htdocs\bas\application\views\Dashboard.php(68): Kohana_Core::error_handler(2, 'Invalid argumen...', 'C:\\xampp\\htdocs...', 68, Array)
#1 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#2 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#3 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(236): Kohana_View->render()
#4 C:\xampp\htdocs\bas\application\views\template.php(81): Kohana_View->__toString()
#5 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(62): include('C:\\xampp\\htdocs...')
#6 C:\xampp\htdocs\bas\system\classes\Kohana\View.php(359): Kohana_View::capture('C:\\xampp\\htdocs...', Array)
#7 C:\xampp\htdocs\bas\system\classes\Kohana\Controller\Template.php(44): Kohana_View->render()
#8 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(87): Kohana_Controller_Template->after()
#9 [internal function]: Kohana_Controller->execute()
#10 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#11 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#12 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#13 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#14 {main} in C:\xampp\htdocs\bas\application\views\Dashboard.php:68
2024-03-27 13:20:19 --- DEBUG: #28 Undefined index: id_dev in C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php:18
2024-03-27 13:21:16 --- DEBUG: #28 Undefined index: id_dev in C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php:18
2024-03-27 13:24:35 --- DEBUG: #28 Undefined index: id_dev in C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php:19
2024-03-27 13:25:32 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id_dev ~ APPPATH\classes\Model\bas.php [ 120 ] in C:\xampp\htdocs\bas\application\classes\Model\bas.php:120
2024-03-27 13:25:32 --- DEBUG: #0 C:\xampp\htdocs\bas\application\classes\Model\bas.php(120): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\\xampp\\htdocs...', 120, Array)
#1 C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php(19): Model_Bas->getBasDeviceList2()
#2 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#5 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#8 {main} in C:\xampp\htdocs\bas\application\classes\Model\bas.php:120
2024-03-27 13:27:50 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id_dev ~ APPPATH\classes\Model\bas.php [ 121 ] in C:\xampp\htdocs\bas\application\classes\Model\bas.php:121
2024-03-27 13:27:50 --- DEBUG: #0 C:\xampp\htdocs\bas\application\classes\Model\bas.php(121): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\\xampp\\htdocs...', 121, Array)
#1 C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php(19): Model_Bas->getBasDeviceList2()
#2 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#5 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#8 {main} in C:\xampp\htdocs\bas\application\classes\Model\bas.php:121
2024-03-27 13:29:46 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id_dev ~ APPPATH\classes\Model\bas.php [ 119 ] in C:\xampp\htdocs\bas\application\classes\Model\bas.php:119
2024-03-27 13:29:46 --- DEBUG: #0 C:\xampp\htdocs\bas\application\classes\Model\bas.php(119): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\\xampp\\htdocs...', 119, Array)
#1 C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php(19): Model_Bas->getBasDeviceList2()
#2 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#5 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#8 {main} in C:\xampp\htdocs\bas\application\classes\Model\bas.php:119
2024-03-27 13:32:03 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: password ~ APPPATH\classes\Model\bas.php [ 136 ] in C:\xampp\htdocs\bas\application\classes\Model\bas.php:136
2024-03-27 13:32:03 --- DEBUG: #0 C:\xampp\htdocs\bas\application\classes\Model\bas.php(136): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 136, Array)
#1 C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php(19): Model_Bas->getBasDeviceList2()
#2 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#5 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#8 {main} in C:\xampp\htdocs\bas\application\classes\Model\bas.php:136
2024-03-27 13:32:23 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ')' ~ APPPATH\classes\Model\bas.php [ 134 ] in file:line
2024-03-27 13:32:23 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-27 13:32:51 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ')' ~ APPPATH\classes\Model\bas.php [ 134 ] in file:line
2024-03-27 13:32:51 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-27 13:33:00 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH\classes\Model\bas.php [ 134 ] in file:line
2024-03-27 13:33:00 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-27 13:34:18 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id_dev ~ APPPATH\classes\Model\bas.php [ 119 ] in C:\xampp\htdocs\bas\application\classes\Model\bas.php:119
2024-03-27 13:34:18 --- DEBUG: #0 C:\xampp\htdocs\bas\application\classes\Model\bas.php(119): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\\xampp\\htdocs...', 119, Array)
#1 C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php(19): Model_Bas->getBasDeviceList2()
#2 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#5 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#8 {main} in C:\xampp\htdocs\bas\application\classes\Model\bas.php:119
2024-03-27 13:34:58 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id_dev ~ APPPATH\classes\Model\bas.php [ 119 ] in C:\xampp\htdocs\bas\application\classes\Model\bas.php:119
2024-03-27 13:34:58 --- DEBUG: #0 C:\xampp\htdocs\bas\application\classes\Model\bas.php(119): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\\xampp\\htdocs...', 119, Array)
#1 C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php(19): Model_Bas->getBasDeviceList2()
#2 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#5 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#8 {main} in C:\xampp\htdocs\bas\application\classes\Model\bas.php:119
2024-03-27 13:40:05 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id_dev ~ APPPATH\classes\Model\bas.php [ 119 ] in C:\xampp\htdocs\bas\application\classes\Model\bas.php:119
2024-03-27 13:40:05 --- DEBUG: #0 C:\xampp\htdocs\bas\application\classes\Model\bas.php(119): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\\xampp\\htdocs...', 119, Array)
#1 C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php(19): Model_Bas->getBasDeviceList2()
#2 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#5 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#8 {main} in C:\xampp\htdocs\bas\application\classes\Model\bas.php:119
2024-03-27 13:55:32 --- CRITICAL: ErrorException [ 8 ]: Undefined index: id_dev ~ APPPATH\classes\Model\bas.php [ 119 ] in C:\xampp\htdocs\bas\application\classes\Model\bas.php:119
2024-03-27 13:55:32 --- DEBUG: #0 C:\xampp\htdocs\bas\application\classes\Model\bas.php(119): Kohana_Core::error_handler(8, 'Undefined index...', 'C:\\xampp\\htdocs...', 119, Array)
#1 C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php(19): Model_Bas->getBasDeviceList2()
#2 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#5 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#8 {main} in C:\xampp\htdocs\bas\application\classes\Model\bas.php:119
2024-03-27 13:56:59 --- CRITICAL: ErrorException [ 8 ]: Use of undefined constant logins - assumed 'logins' ~ APPPATH\classes\Model\bas.php [ 115 ] in C:\xampp\htdocs\bas\application\classes\Model\bas.php:115
2024-03-27 13:56:59 --- DEBUG: #0 C:\xampp\htdocs\bas\application\classes\Model\bas.php(115): Kohana_Core::error_handler(8, 'Use of undefine...', 'C:\\xampp\\htdocs...', 115, Array)
#1 C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php(19): Model_Bas->getBasDeviceList2()
#2 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#5 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#8 {main} in C:\xampp\htdocs\bas\application\classes\Model\bas.php:115
2024-03-27 13:57:57 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: id_dev ~ APPPATH\classes\Model\bas.php [ 117 ] in C:\xampp\htdocs\bas\application\classes\Model\bas.php:117
2024-03-27 13:57:57 --- DEBUG: #0 C:\xampp\htdocs\bas\application\classes\Model\bas.php(117): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 117, Array)
#1 C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php(19): Model_Bas->getBasDeviceList2()
#2 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_index()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#5 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#8 {main} in C:\xampp\htdocs\bas\application\classes\Model\bas.php:117
2024-03-27 13:59:26 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: deviceList2 ~ APPPATH\classes\Controller\Dashboard.php [ 21 ] in C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php:21
2024-03-27 13:59:26 --- DEBUG: #0 C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php(21): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 21, Array)
#1 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Dashboard->action_index()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Dashboard))
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#7 {main} in C:\xampp\htdocs\bas\application\classes\Controller\Dashboard.php:21
2024-03-27 14:23:52 --- CRITICAL: ErrorException [ 4 ]: syntax error, unexpected '(', expecting ',' or ';' ~ APPPATH\views\Dashboard.php [ 87 ] in file:line
2024-03-27 14:23:52 --- DEBUG: #0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main} in file:line
2024-03-27 14:40:30 --- DEBUG: #47 Данные из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(14)</span> "192.168.89.122"
        "id_dev" => <small>string</small><span>(2)</span> "88"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> удалеы успешно перед последующей вставкой. SQL=delete from bas_param bp
				where bp.id_dev=88
				and bp.param='IP' in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:40:30 --- DEBUG: #t6-time 0.021087884902954 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:40:30 --- DEBUG: #54 Данные из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(14)</span> "192.168.89.122"
        "id_dev" => <small>string</small><span>(2)</span> "88"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> вставлены успешно. SQL=INSERT INTO BAS_PARAM (ID_DEV, PARAM, INTVALUE) VALUES (88, 'IP',  '-1062708870'); in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:40:30 --- DEBUG: #84-time 0.022281885147095 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:40:30 --- DEBUG: #99-time 0.022290945053101 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:40:30 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: result ~ APPPATH\classes\Model\bas.php [ 56 ] in C:\xampp\htdocs\bas\application\classes\Model\bas.php:56
2024-03-27 14:40:30 --- DEBUG: #0 C:\xampp\htdocs\bas\application\classes\Model\bas.php(56): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 56, Array)
#1 C:\xampp\htdocs\bas\application\classes\Controller\Oop.php(81): Model_Bas->changeConfigIP(Object(Validation))
#2 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Oop->action_control_no_model()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Oop))
#5 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#8 {main} in C:\xampp\htdocs\bas\application\classes\Model\bas.php:56
2024-03-27 14:40:37 --- DEBUG: #47 Данные из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(13)</span> "192.168.89.12"
        "id_dev" => <small>string</small><span>(2)</span> "88"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> удалеы успешно перед последующей вставкой. SQL=delete from bas_param bp
				where bp.id_dev=88
				and bp.param='IP' in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:40:37 --- DEBUG: #t6-time 0.020868062973022 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:40:37 --- DEBUG: #54 Данные из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(13)</span> "192.168.89.12"
        "id_dev" => <small>string</small><span>(2)</span> "88"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> вставлены успешно. SQL=INSERT INTO BAS_PARAM (ID_DEV, PARAM, INTVALUE) VALUES (88, 'IP',  '-1062708980'); in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:40:37 --- DEBUG: #84-time 0.022178173065186 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:40:37 --- DEBUG: #99-time 0.022186040878296 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:40:37 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: result ~ APPPATH\classes\Model\bas.php [ 56 ] in C:\xampp\htdocs\bas\application\classes\Model\bas.php:56
2024-03-27 14:40:37 --- DEBUG: #0 C:\xampp\htdocs\bas\application\classes\Model\bas.php(56): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 56, Array)
#1 C:\xampp\htdocs\bas\application\classes\Controller\Oop.php(81): Model_Bas->changeConfigIP(Object(Validation))
#2 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Oop->action_control_no_model()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Oop))
#5 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#8 {main} in C:\xampp\htdocs\bas\application\classes\Model\bas.php:56
2024-03-27 14:41:42 --- DEBUG: #47 Данные из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(13)</span> "192.168.89.12"
        "id_dev" => <small>string</small><span>(2)</span> "88"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> удалеы успешно перед последующей вставкой. SQL=delete from bas_param bp
				where bp.id_dev=88
				and bp.param='IP' in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:41:42 --- DEBUG: #t6-time 0.024297952651978 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:53:36 --- DEBUG: #47 Данные из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(13)</span> "192.168.89.22"
        "id_dev" => <small>string</small><span>(2)</span> "88"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> удалеы успешно перед последующей вставкой. SQL=delete from bas_param bp
				where bp.id_dev=88
				and bp.param='IP' in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:53:36 --- DEBUG: #t6-time 0.022094964981079 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:53:36 --- DEBUG: #54 Данные из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(13)</span> "192.168.89.22"
        "id_dev" => <small>string</small><span>(2)</span> "88"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> вставлены успешно. SQL=INSERT INTO BAS_PARAM (ID_DEV, PARAM, INTVALUE) VALUES (88, 'IP',  '-1062708970'); in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:53:36 --- DEBUG: #84-time 0.023439884185791 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:53:36 --- DEBUG: #99-time 0.023448944091797 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:53:36 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: result ~ APPPATH\classes\Model\bas.php [ 57 ] in C:\xampp\htdocs\bas\application\classes\Model\bas.php:57
2024-03-27 14:53:36 --- DEBUG: #0 C:\xampp\htdocs\bas\application\classes\Model\bas.php(57): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 57, Array)
#1 C:\xampp\htdocs\bas\application\classes\Controller\Oop.php(81): Model_Bas->changeConfigIP(Object(Validation))
#2 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Oop->action_control_no_model()
#3 [internal function]: Kohana_Controller->execute()
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Oop))
#5 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#6 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#7 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#8 {main} in C:\xampp\htdocs\bas\application\classes\Model\bas.php:57
2024-03-27 14:55:20 --- DEBUG: #47 Данные из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(13)</span> "192.168.89.22"
        "id_dev" => <small>string</small><span>(2)</span> "88"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> удалеы успешно перед последующей вставкой. SQL=delete from bas_param bp
				where bp.id_dev=88
				and bp.param='IP' in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:55:20 --- DEBUG: #t6-time 0.025695085525513 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:55:20 --- DEBUG: #54 Данные из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(13)</span> "192.168.89.22"
        "id_dev" => <small>string</small><span>(2)</span> "88"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> вставлены успешно. SQL=INSERT INTO BAS_PARAM (ID_DEV, PARAM, INTVALUE) VALUES (88, 'IP',  '-1062708970'); in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:55:20 --- DEBUG: #84-time 0.027337074279785 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:55:20 --- DEBUG: #99-time 0.027345895767212 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:55:25 --- DEBUG: #47 Данные из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(14)</span> "192.168.89.222"
        "id_dev" => <small>string</small><span>(2)</span> "88"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> удалеы успешно перед последующей вставкой. SQL=delete from bas_param bp
				where bp.id_dev=88
				and bp.param='IP' in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:55:25 --- DEBUG: #t6-time 0.021185874938965 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:55:25 --- DEBUG: #54 Данные из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(14)</span> "192.168.89.222"
        "id_dev" => <small>string</small><span>(2)</span> "88"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> вставлены успешно. SQL=INSERT INTO BAS_PARAM (ID_DEV, PARAM, INTVALUE) VALUES (88, 'IP',  '-1062708770'); in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:55:25 --- DEBUG: #84-time 0.022592782974243 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:55:25 --- DEBUG: #99-time 0.022601842880249 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:55:48 --- DEBUG: #47 Данные из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(14)</span> "192.168.89.122"
        "id_dev" => <small>string</small><span>(2)</span> "88"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> удалеы успешно перед последующей вставкой. SQL=delete from bas_param bp
				where bp.id_dev=88
				and bp.param='IP' in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:55:48 --- DEBUG: #t6-time 0.021866798400879 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:55:48 --- DEBUG: #54 Данные из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(14)</span> "192.168.89.122"
        "id_dev" => <small>string</small><span>(2)</span> "88"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> вставлены успешно. SQL=INSERT INTO BAS_PARAM (ID_DEV, PARAM, INTVALUE) VALUES (88, 'IP',  '-1062708870'); in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:55:48 --- DEBUG: #84-time 0.023138999938965 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:55:48 --- DEBUG: #99-time 0.023147821426392 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:59:52 --- DEBUG: #47 Данные из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(13)</span> "192.168.89.12"
        "id_dev" => <small>string</small><span>(2)</span> "88"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> удалеы успешно перед последующей вставкой. SQL=delete from bas_param bp
				where bp.id_dev=88
				and bp.param='IP' in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:59:52 --- DEBUG: #t6-time 0.022949934005737 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:59:52 --- DEBUG: #54 Данные из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(13)</span> "192.168.89.12"
        "id_dev" => <small>string</small><span>(2)</span> "88"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> вставлены успешно. SQL=INSERT INTO BAS_PARAM (ID_DEV, PARAM, INTVALUE) VALUES (88, 'IP',  '-1062708980'); in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:59:52 --- DEBUG: #84-time 0.024212837219238 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:59:52 --- DEBUG: #99-time 0.024222850799561 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 14:59:52 --- CRITICAL: ErrorException [ 8 ]: Undefined variable: id_dev ~ APPPATH\classes\Controller\Oop.php [ 83 ] in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:83
2024-03-27 14:59:52 --- DEBUG: #0 C:\xampp\htdocs\bas\application\classes\Controller\Oop.php(83): Kohana_Core::error_handler(8, 'Undefined varia...', 'C:\\xampp\\htdocs...', 83, Array)
#1 C:\xampp\htdocs\bas\system\classes\Kohana\Controller.php(84): Controller_Oop->action_control_no_model()
#2 [internal function]: Kohana_Controller->execute()
#3 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client\Internal.php(97): ReflectionMethod->invoke(Object(Controller_Oop))
#4 C:\xampp\htdocs\bas\system\classes\Kohana\Request\Client.php(114): Kohana_Request_Client_Internal->execute_request(Object(Request), Object(Response))
#5 C:\xampp\htdocs\bas\system\classes\Kohana\Request.php(997): Kohana_Request_Client->execute(Object(Request))
#6 C:\xampp\htdocs\bas\index.php(118): Kohana_Request->execute()
#7 {main} in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:83
2024-03-27 15:00:15 --- DEBUG: #47 Данные из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(13)</span> "192.168.89.12"
        "id_dev" => <small>string</small><span>(2)</span> "88"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> удалеы успешно перед последующей вставкой. SQL=delete from bas_param bp
				where bp.id_dev=88
				and bp.param='IP' in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 15:00:15 --- DEBUG: #t6-time 0.022185087203979 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 15:00:15 --- DEBUG: #54 Данные из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(13)</span> "192.168.89.12"
        "id_dev" => <small>string</small><span>(2)</span> "88"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> вставлены успешно. SQL=INSERT INTO BAS_PARAM (ID_DEV, PARAM, INTVALUE) VALUES (88, 'IP',  '-1062708980'); in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 15:00:15 --- DEBUG: #84-time 0.023730039596558 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 15:00:15 --- DEBUG: #99-time 0.023746967315674 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 15:05:52 --- DEBUG: #47 Данные из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(13)</span> "192.168.89.10"
        "id_dev" => <small>string</small><span>(2)</span> "88"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> удалеы успешно перед последующей вставкой. SQL=delete from bas_param bp
				where bp.id_dev=88
				and bp.param='IP' in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 15:05:52 --- DEBUG: #t6-time 0.020703792572021 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 15:05:52 --- DEBUG: #54 Данные из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(13)</span> "192.168.89.10"
        "id_dev" => <small>string</small><span>(2)</span> "88"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> вставлены успешно. SQL=INSERT INTO BAS_PARAM (ID_DEV, PARAM, INTVALUE) VALUES (88, 'IP',  '-1062708982'); in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 15:05:52 --- DEBUG: #84-time 0.021919965744019 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 15:05:52 --- DEBUG: #99-time 0.021929025650024 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 17:24:21 --- DEBUG: #47 Данные из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(13)</span> "192.168.89.12"
        "id_dev" => <small>string</small><span>(2)</span> "88"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> удалеы успешно перед последующей вставкой. SQL=delete from bas_param bp
				where bp.id_dev=88
				and bp.param='IP' in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 17:24:21 --- DEBUG: #t6-time 0.060595035552979 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 17:24:21 --- DEBUG: #54 Данные из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(13)</span> "192.168.89.12"
        "id_dev" => <small>string</small><span>(2)</span> "88"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> вставлены успешно. SQL=INSERT INTO BAS_PARAM (ID_DEV, PARAM, INTVALUE) VALUES (88, 'IP',  '-1062708980'); in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 17:24:21 --- DEBUG: #84-time 0.06309700012207 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 17:24:21 --- DEBUG: #99-time 0.063107967376709 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 17:26:58 --- DEBUG: #47 Данные из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(14)</span> "192.168.89.111"
        "id_dev" => <small>string</small><span>(2)</span> "91"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> удалеы успешно перед последующей вставкой. SQL=delete from bas_param bp
				where bp.id_dev=91
				and bp.param='IP' in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 17:26:58 --- DEBUG: #t6-time 0.024724006652832 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 17:26:58 --- DEBUG: #54 Данные из набора <pre class="debug"><small>object</small> <span>Validation(6)</span> <code>{
    <small>protected</small> _bound => <small>array</small><span>(0)</span> 
    <small>protected</small> _rules => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(5)</span> "digit"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
        "new_IP" => <small>array</small><span>(2)</span> <span>(
            0 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(9)</span> "not_empty"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
            1 => <small>array</small><span>(2)</span> <span>(
                0 => <small>string</small><span>(2)</span> "IP"
                1 => <small>array</small><span>(1)</span> <span>(
                    0 => <small>string</small><span>(6)</span> ":value"
                )</span>
            )</span>
        )</span>
    )</span>
    <small>protected</small> _labels => <small>array</small><span>(2)</span> <span>(
        "id_dev" => <small>string</small><span>(6)</span> "id_dev"
        "new_IP" => <small>string</small><span>(6)</span> "new_IP"
    )</span>
    <small>protected</small> _empty_rules => <small>array</small><span>(2)</span> <span>(
        0 => <small>string</small><span>(9)</span> "not_empty"
        1 => <small>string</small><span>(7)</span> "matches"
    )</span>
    <small>protected</small> _errors => <small>array</small><span>(0)</span> 
    <small>protected</small> _data => <small>array</small><span>(4)</span> <span>(
        "new_IP" => <small>string</small><span>(14)</span> "192.168.89.111"
        "id_dev" => <small>string</small><span>(2)</span> "91"
        "todo" => <small>string</small><span>(13)</span> "bas_changeIP2"
        "submit" => <small>string</small><span>(24)</span> "Новый IP адрес"
    )</span>
}</code></pre> вставлены успешно. SQL=INSERT INTO BAS_PARAM (ID_DEV, PARAM, INTVALUE) VALUES (91, 'IP',  '-1062708881'); in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 17:26:58 --- DEBUG: #84-time 0.026185989379883 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81
2024-03-27 17:26:58 --- DEBUG: #99-time 0.026196002960205 in C:\xampp\htdocs\bas\application\classes\Controller\Oop.php:81