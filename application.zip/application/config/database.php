<?php defined('SYSPATH') OR die('No direct access allowed.');

return array
(	'fb2' => array(
		'type'			=> 'pdo',
		'connection'	=> array(
			//'dsn'		=> 'firebird:dbname=127.0.0.1:C:\\Program Files (x86)\\Cardsoft\\DuoSE\\Access\\SHIELDPRO_REST.GDB',
			//'dsn'		=> 'firebird:dbname=127.0.0.1:C:\\Users\Андрей\\Documents\\Проекты\\2017 проекты\\2017_04_12 Обновление Доминиона до Сити\\SHIELDPRO_REST.GDB',
			//'dsn'		=> 'firebird:dbname=127.0.0.1:C:\ttt\111.GDB',
			//'dsn'       => 'odbc:SDUO_HL',
			'dsn'       => 'odbc:SDUO',
			'username'	=> 'SYSDBA',
			'password'	=> 'temp',
			//'charset'   => 'windows-1251',
			'charset'   => 'UTF8',
				
			)
		),
		
		'fb1' => array(
		'type'			=> 'pdo',
		'connection'	=> array(
			'dsn'		=> 'firebird:dbname=127.0.0.1:C:\xampp\htdocs\222.GDB',
			'username'	=> 'SYSDBA',
			'password'	=> 'temp',
			'charset'   => 'windows-1251',
			)
		),
		
	'fb' =>array(
				'type'			=> 'pdo',
				'connection'	=> array(
					'dsn'		=> 'odbc:Test',
					'charset'   => 'UTF8',
					//'charset'   => 'windows-1251',
					)
				),
   
			
);
