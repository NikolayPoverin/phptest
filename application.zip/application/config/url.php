<?php

return [
	'trusted_hosts' => array(
        'localhost',
		'192.168.0.18',
    ),
];
