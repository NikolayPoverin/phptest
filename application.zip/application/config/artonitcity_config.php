<?php defined('SYSPATH') or die('No direct script access.');
 
return array(
    'dir_log' => 'C:\Program Files\Cardsoft\DuoSE\Access\Log',
    'dir_compare' => 'C:\xampp\htdocs\city',
    'stat_day_befor' => 7,
    'name_device_fro_test' => 'ademant-1000-41',
	'city_name' => 'Хедлайнер 2 Bas-IP',
	'ver'=>'1.2.6',
	'developer'=>'www.artonit.ru',
		'main_windows'=>array(
				'windows1'=>true, // окно №1  Информация по жильцам и картам
				'windows2'=>false, // окно №2 Оборудование
				'windows3'=>false, // окно №3 Очередь загрузок
				'windows4'=>false, // окно №4 События
				'windows5'=>false, // окно №5 Изменения системы
				'windows6'=>true, // окно №6 Статистика событий
				'windows7'=>true, // окно №7 Информация о парковках
				'windows8'=>true, // окно №6 Информация о счетчиках свободных мест
				
				
		),
);